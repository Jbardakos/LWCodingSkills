---
name: shaders
description: >
  Use this skill for LightWave shader plugins in both C/C++ (LWShaderHandler) and
  LScript (@script shader). Covers the evaluate/process pattern, LWShaderAccess
  fields, shader flags, raytracing functions, load/save, and XPanels/requester UI.
  Trigger when a user asks to write, build, or debug a surface shader in C or LScript.
---

# LightWave Shaders

## ⚠️ STEP 0: READ THE CORRECT TEMPLATE FIRST ⚠️

| Language | Task | Template |
|----------|------|---------|
| C / C++ | Classic shader plugin | `templates/shader_classic.c` |
| LScript | Surface shader script | `templates/shader_lscript.ls` |

Use the template as the **literal starting point**. Replace `PLUGIN_NAME`.
Implement the `Evaluate` / `process` function. Do not write from scratch.

---

## Shader Types

| Type | Header | Version constant | Description |
|------|--------|-----------------|-------------|
| Classic Shader | `lwshader.h` | `LWSHADER_VERSION` | Modify surface params per point |
| Surface Shader (PBR) | `lwsurfaceshader.h` | `LWSURFACESHADER_VERSION` | Full BSDF integrator |
| Texture (procedural) | `lwtxtr.h` | `LWTEXTURE_VERSION` | Texture layer input |

Use **Classic Shader** for most per-point surface modifications.
Use **Surface Shader** only for full PBR BSDF replacement.

---

## Classic Shader — C

### Activation Signature

```c
XCALL_( int )
Activate( int version, GlobalFunc *global,
          LWShaderHandler *local, void *serverData )
{
    if ( version != LWSHADER_VERSION ) return AFUNC_BADVERSION;
    local->inst->create  = Create;
    local->inst->destroy = Destroy;
    local->inst->copy    = Copy;
    local->inst->load    = Load;
    local->inst->save    = Save;
    local->inst->descln  = Descln;
    local->evaluate      = Evaluate;
    local->flags         = Flags;
    return AFUNC_OK;
}
```

### Shader Flags

Return from `Flags()` to declare which channels you modify:

```c
return LWSHF_COLOR;
return LWSHF_COLOR | LWSHF_DIFFUSE;
```

| Flag | Channel |
|------|---------|
| `LWSHF_COLOR` | `sa->color[3]` |
| `LWSHF_LUMINOSITY` | `sa->luminosity` |
| `LWSHF_DIFFUSE` | `sa->diffuse` |
| `LWSHF_SPECULAR` | `sa->specular` |
| `LWSHF_MIRROR` | `sa->mirror` |
| `LWSHF_TRANSPARENCY` | `sa->transparency` |

### LWShaderAccess Fields

```c
/* Geometry (read-only) */
sa->oPos[3]        /* object-space position */
sa->wPos[3]        /* world-space position  */
sa->gNorm[3]       /* geometric normal      */
sa->wNorm[3]       /* shading normal        */
sa->u, sa->v       /* UV coordinates        */

/* Surface channels (read/write — only those declared in Flags) */
sa->color[3]       /* RGB, 0–1              */
sa->luminosity     /* 0–1                   */
sa->diffuse        /* 0–1                   */
sa->specular       /* 0–1                   */
sa->mirror         /* 0–1                   */
sa->transparency   /* 0–1                   */
sa->eta            /* refraction index      */
sa->roughness      /* 0–1                   */

/* Render state */
sa->bounce         /* recursion depth       */

/* Raytracing — ALWAYS check for NULL before calling */
sa->rayTrace       /* trace ray → colour  */
sa->illuminate     /* query a light       */
sa->rayCast        /* ray distance only   */
sa->rayShade       /* ray + shade surface */
```

### Raytracing in Evaluate (C)

```c
if ( sa->rayTrace ) {
    double dir[3]   = { sa->wNorm[0], sa->wNorm[1], sa->wNorm[2] };
    double color[3] = { 0, 0, 0 };
    double len      = sa->rayTrace( sa->wPos, dir, color );
    /* mix color into sa->color */
}
```

---

## Classic Shader — LScript

### Script Header

```lscript
@version 2.3
@warnings
@script shader
@name MyShader
```

### Lifecycle UDFs

```
create     — applied to surface; set defaults, setdesc()
destroy    — cleanup
flags()    — return channel flags: COLOR, DIFFUSE, SPECULAR, etc.
init       — pre-render; cache invariants
cleanup    — post-render
process: sa — per-point evaluation
options    — UI (requester)
load/save  — scene persistence
```

### Shader Object Agent (`sa`) in LScript

```lscript
process: sa
{
    // Read-only
    pos  = sa.oPos;           // <x,y,z>
    wpos = sa.wPos;
    norm = sa.wNorm;          // shading normal
    uv   = <sa.u, sa.v, 0>;

    // Read/write (only channels declared in flags())
    col  = sa.color;          // <r,g,b> 0-1
    sa.color = col * 0.5;

    // Raytracing (returns array: [length, r, g, b])
    // result = sa.raytrace(sa.wPos, sa.wNorm);
    // len = result[1]; r = result[2]; g = result[3]; b = result[4];
}
```

### LScript Shader Flags

```lscript
flags { return(COLOR); }
flags { return(COLOR | DIFFUSE); }
```

Flag names: `COLOR`, `LUMINOSITY`, `DIFFUSE`, `SPECULAR`,
`MIRROR`, `TRANSPARENCY`, `ETA`, `ROUGHNESS`

---

## Surface Shader (PBR / LW2018+) — C

For full BSDF integrators only. Header: `lwsurfaceshader.h`.

```c
typedef struct st_LWSurfaceShaderHandler {
    LWInstanceFuncs *inst;
    LWItemFuncs     *item;
    LWRenderFuncs   *rend;
    double (*shade)(LWInstance, const LWRay*, LWShadingGeometry*,
                    LWBSDF bsdf, LWDVector result);
    double (*F)(LWInstance, const LWRay*, LWShadingGeometry*,
                LWBSDF, const LWDVector wo, const LWDVector wi,
                unsigned int flags, LWDVector f);
    void   (*sampleF)(LWInstance, const LWRay*, LWShadingGeometry*,
                      LWBSDF, const LWDVector sample,
                      LWBxDFSample* so, unsigned int bxdfFlags);
} LWSurfaceShaderHandler;
```

`shade()` — evaluate the full BSDF, write result colour.
`F()` — evaluate BSDF for given incoming/outgoing directions.
`sampleF()` — importance-sample the BSDF.

---

## File Placement

Classic shaders (`.p` or `.ls`) load via **Surface Editor > Shaders > Add Shader**.
Copy to `LightWave/Plugins/Shaders/` and **Edit > Refresh Plugins**.

---

## Gotchas

1. **Raytracing functions may be NULL** during Surface Editor preview — always
   check before calling: `if ( sa->rayTrace ) { ... }`.
2. **Only modify channels declared in `Flags()`** — LightWave may ignore others.
3. **`sa->bounce` prevents infinite recursion** — check it before firing rays.
4. **`Evaluate` / `process` is called per shading point** — keep it fast; no heap
   allocation, no file I/O.
5. **LScript `process: sa` does not get a `time` argument** — use `gettime()` if
   you need current render time.
6. **`init` / `cleanup` bracket each render pass** — pre-compute there, not in `process`.
7. **C Load/Save must match in order** — mismatches silently corrupt scene data.
