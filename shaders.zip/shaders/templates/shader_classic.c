/*
 * PLUGIN_NAME — LightWave Classic Shader Plugin (C/C++)
 * TODO: Replace PLUGIN_NAME throughout this file
 *
 * TEMPLATE: Shader Handler (classic LWShaderHandler)
 * Classic shaders modify surface parameters per shading point.
 * They are applied via the Surface Editor > Shaders tab.
 *
 * NOTE: For PBR/BSDF workflows, use LWSurfaceShaderHandler instead
 * (lwsurfaceshader.h). This template targets the classic shader which
 * is still widely used and well-documented.
 */

#include <lwserver.h>
#include <lwshader.h>     /* LWShaderHandler, LWShaderAccess, LWSHADER_CLASS */
#include <lwxpanel.h>
#include <lwmessage.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* ------------------------------------------------------------------ */
/* Instance data                                                         */
/* ------------------------------------------------------------------ */
typedef struct {
    /* TODO: shader parameters, e.g.: */
    double  blendColor[3];   /* RGB, 0-1         */
    double  blendAmount;     /* 0-1              */
    double  radius;          /* world-space radius */
} MyShader;

/* ------------------------------------------------------------------ */
/* Instance callbacks                                                   */
/* ------------------------------------------------------------------ */

static LWInstance
Create( void *priv, void *context, LWError *err )
{
    MyShader *dat = (MyShader *)calloc( 1, sizeof(MyShader) );
    if ( !dat ) { *err = "Out of memory"; return NULL; }
    dat->blendColor[0] = 1.0;
    dat->blendColor[1] = 0.0;
    dat->blendColor[2] = 0.0;
    dat->blendAmount   = 0.5;
    dat->radius        = 0.5;
    return (LWInstance)dat;
}

static void Destroy ( LWInstance inst ) { if (inst) free(inst); }

static LWError
Copy( LWInstance to, LWInstance from )
{
    *(MyShader *)to = *(MyShader *)from;
    return NULL;
}

static LWError
Load( LWInstance inst, const LWLoadState *ls )
{
    MyShader *dat = (MyShader *)inst;
    LWLOAD_FP( ls, dat->blendColor, 3 );
    LWLOAD_FP( ls, &dat->blendAmount, 1 );
    LWLOAD_FP( ls, &dat->radius, 1 );
    return NULL;
}

static LWError
Save( LWInstance inst, const LWSaveState *ss )
{
    MyShader *dat = (MyShader *)inst;
    LWSAVE_FP( ss, dat->blendColor, 3 );
    LWSAVE_FP( ss, &dat->blendAmount, 1 );
    LWSAVE_FP( ss, &dat->radius, 1 );
    return NULL;
}

static const char *
Descln( LWInstance inst )
{
    static char buf[80];
    MyShader *dat = (MyShader *)inst;
    sprintf( buf, "PLUGIN_NAME blend=%.2f", dat->blendAmount );
    return buf;
}

/* ------------------------------------------------------------------ */
/* Flags — declare which surface channels this shader modifies          */
/* ------------------------------------------------------------------ */

static unsigned int
Flags( LWInstance inst )
{
    /* Combine with | for multiple channels */
    return LWSHF_COLOR;
    /* Other flags:
     * LWSHF_LUMINOSITY  LWSHF_DIFFUSE   LWSHF_SPECULAR
     * LWSHF_MIRROR      LWSHF_TRANSPARENCY              */
}

/* ------------------------------------------------------------------ */
/* Evaluate — called per shading point during render                    */
/* ------------------------------------------------------------------ */

static void
Evaluate( LWInstance inst, LWShaderAccess *sa )
{
    MyShader *dat = (MyShader *)inst;

    /*
     * sa->oPos[3]          object-space position (read-only)
     * sa->wPos[3]          world-space position  (read-only)
     * sa->gNorm[3]         geometric normal      (read-only)
     * sa->wNorm[3]         shading normal        (read-only)
     *
     * Writable surface channels:
     * sa->color[3]         surface colour (RGB, 0-1)
     * sa->luminosity       0-1
     * sa->diffuse          0-1
     * sa->specular         0-1
     * sa->mirror           0-1
     * sa->transparency     0-1
     * sa->eta              refraction index
     * sa->roughness        0-1
     *
     * Raytrace functions (may be NULL — ALWAYS check before calling):
     * sa->rayTrace         fire a ray and get colour
     * sa->illuminate       query a light
     * sa->rayCast          ray distance only (faster)
     * sa->rayShade         ray + shade nearest surface
     * sa->bounce           recursion depth counter
     */

    /* TODO: implement shader logic, e.g. blend with a colour by radius: */
    double dx = sa->oPos[0];
    double dy = sa->oPos[1];
    double dz = sa->oPos[2];
    double dist = sqrt( dx*dx + dy*dy + dz*dz );

    if ( dist < dat->radius ) {
        double t = (1.0 - dist / dat->radius) * dat->blendAmount;
        sa->color[0] = sa->color[0] * (1.0 - t) + dat->blendColor[0] * t;
        sa->color[1] = sa->color[1] * (1.0 - t) + dat->blendColor[1] * t;
        sa->color[2] = sa->color[2] * (1.0 - t) + dat->blendColor[2] * t;
    }
}

/* ------------------------------------------------------------------ */
/* Interface activation (XPanels)                                       */
/* ------------------------------------------------------------------ */

#define CTRL_AMOUNT 1
#define CTRL_RADIUS 2

static LWXPanelHint panelHints[] = {
    XpLABEL( 0,           "PLUGIN_NAME"   ),
    XpF64  ( CTRL_AMOUNT, "Blend Amount"  ),
    XpF64  ( CTRL_RADIUS, "Radius"        ),
    XpEND
};

XCALL_( static int )
Interface( int version, GlobalFunc *global,
           LWInterface *local, void *serverData )
{
    LWXPanelFuncs *xpanf = global( LWXPANELFUNCS_GLOBAL, GFUSE_TRANSIENT );
    MyShader      *dat   = (MyShader *)local->inst;
    if ( !xpanf ) return AFUNC_BADGLOBAL;

    local->panel   = xpanf->create( LWXP_VIEW, panelHints );
    local->options = NULL;
    local->command = NULL;

    if ( local->panel ) {
        xpanf->formSet( local->panel, CTRL_AMOUNT, &dat->blendAmount );
        xpanf->formSet( local->panel, CTRL_RADIUS, &dat->radius );
    }
    return AFUNC_OK;
}

/* ------------------------------------------------------------------ */
/* Activation function                                                   */
/* ------------------------------------------------------------------ */

XCALL_( int )
Activate( int version, GlobalFunc *global,
          LWShaderHandler *local, void *serverData )
{
    if ( version != LWSHADER_VERSION ) return AFUNC_BADVERSION;

    local->inst->create  = Create;
    local->inst->destroy = Destroy;
    local->inst->copy    = Copy;
    local->inst->load    = Load;
    local->inst->save    = Save;
    local->inst->descln  = Descln;

    if ( local->item ) {
        local->item->useItems = NULL;
        local->item->changeID = NULL;
    }

    local->evaluate = Evaluate;
    local->flags    = Flags;
    return AFUNC_OK;
}

/* ------------------------------------------------------------------ */
/* Server record                                                         */
/* ------------------------------------------------------------------ */
ServerRecord ServerDesc[] = {
    { LWSHADER_CLASS, "PLUGIN_NAME",           Activate  },
    { LWSHADER_CLASS, "PLUGIN_NAME_Interface", Interface },
    { NULL }
};
