@version 2.3
@warnings
@script shader
@name PLUGIN_NAME

// ============================================================
// TODO: Replace PLUGIN_NAME above with your script name
// TEMPLATE: Shader Script (LScript)
// Applied via: Surface Editor > Shaders tab
// Called per shading point during render.
// ============================================================

// Global parameters
// TODO: declare your parameters here, e.g.:
// blendColor  = <1.0, 0.0, 0.0>;
// blendAmount = 0.5;
// radius      = 0.5;

create
{
    setdesc("PLUGIN_NAME");
    // TODO: set defaults, inspect surface
}

destroy
{
}

// flags() tells LightWave which surface channels you will modify.
// Return a combination of: COLOR, LUMINOSITY, DIFFUSE,
// SPECULAR, MIRROR, TRANSPARENCY, ETA, ROUGHNESS
flags
{
    return(COLOR);
}

// init() is called once before the render begins.
// Pre-compute any values that don't change per point.
init
{
    // TODO: pre-render cache
}

// cleanup() is called after render completes.
cleanup
{
}

// process() is the core evaluation — called per shading point.
// sa = Shader Object Agent
process: sa
{
    // Shader Object Agent members (read):
    // sa.oPos      — object-space position <x,y,z>
    // sa.wPos      — world-space position  <x,y,z>
    // sa.gNorm     — geometric normal      <x,y,z>
    // sa.wNorm     — shading normal        <x,y,z>
    // sa.color     — current surface color  <r,g,b>  (read/write)
    // sa.luminosity
    // sa.diffuse
    // sa.specular
    // sa.mirror
    // sa.transparency
    // sa.eta        — refraction index
    // sa.roughness

    // TODO: compute and modify sa.color (and other channels), e.g.:
    // dx = sa.oPos.x;
    // dy = sa.oPos.y;
    // dz = sa.oPos.z;
    // dist = sqrt(dx*dx + dy*dy + dz*dz);
    //
    // if(dist < radius)
    // {
    //     t = (1.0 - dist / radius) * blendAmount;
    //     sa.color = sa.color * (1.0 - t) + blendColor * t;
    // }
}

// options() is the UI — shown when user double-clicks the shader
options
{
    reqbegin("PLUGIN_NAME");

        // TODO: controls for your parameters, e.g.:
        // c1 = ctlcolor("Blend Color", blendColor);
        // c2 = ctlnumber("Blend Amount", blendAmount);
        // c3 = ctlnumber("Radius (m)", radius);

    return if !reqpost();

        // TODO: read values, e.g.:
        // blendColor  = getvalue(c1);
        // blendAmount = getvalue(c2);
        // radius      = getvalue(c3);

    reqend();
    setdesc("PLUGIN_NAME");   // TODO: update with current values
}

load: what, io
{
    if(what == SCENEMODE)
    {
        // TODO: io.read() for each saved variable (same order as save)
    }
}

save: what, io
{
    if(what == SCENEMODE)
    {
        // TODO: io.writeln() for each variable
    }
}
