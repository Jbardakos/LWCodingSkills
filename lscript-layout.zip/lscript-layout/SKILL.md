---
name: lscript-layout
description: >
  Use this skill for any LScript code targeting LightWave Layout. Covers all Layout
  script types: Item Animation (motion), Channel Filter, Generic, Master Class.
  Includes Object Agent methods, scene I/O, load/save scene data, options() UI.
  Trigger when a user asks to write, debug, or extend an LScript (.ls) for Layout
  tasks: motion control, channel constraints, scene automation, or rendering hooks.
---

# LScript — Layout Scripting

## ⚠️ STEP 0: READ THE CORRECT TEMPLATE FIRST ⚠️

Before writing any Layout LScript, read the appropriate template and use it as
the **literal starting point**. Replace all `PLUGIN_NAME` tokens. Fill in `TODO`.

| Task | Template to read |
|------|-----------------|
| Per-frame motion / transform control | `templates/motion_handler.ls` |
| Clamp or modify individual channel values | `templates/channel_filter.ls` |
| One-shot scene automation tool | `templates/generic.ls` |

---

## Script Types

| `@script` | Class | Use |
|-----------|-------|-----|
| `motion` | Item Animation | per-frame transform control |
| `channel` | Channel Filter | single channel clamp/modify |
| `generic` | Generic | one-shot Layout tool |
| `master` | Master Class | scene-global event handler |
| `displacement` | Displacement | per-vertex deformation |
| `shader` | Shader | surface shading |

---

## Lifecycle Functions

```
              motion  channel  generic  master
create          ✓       ✓        —        ✓
destroy         ✓       ✓        —        ✓
process         ✓       ✓        —        ✓
generic()       —       —        ✓        —
options         ✓       ✓        —        ✓
load/save       ✓       ✓        —        ✓
event           —       —        —        ✓
```

---

## Motion Access Object Agent (`ma`)

```lscript
pos = ma.get(POSITION, time);   // <x,y,z> metres
rot = ma.get(ROTATION, time);   // <h,p,b> degrees
scl = ma.get(SCALING,  time);

ma.set(POSITION, <x, y, z>);
ma.set(ROTATION, <h, p, b>);
ma.set(SCALING,  <sx, sy, sz>);
```

Constants: `POSITION`, `ROTATION`, `SCALING`, `PIVOT`, `WORLDPOSITION`

---

## Scene Item Object Agents

```lscript
obj  = Object("ObjectName.lwo");
mesh = Mesh("ObjectName.lwo");
pos  = obj.param(POSITION, time);   // READ-ONLY — returns <x,y,z>

// Traverse scene
first = getfirstitem(MESH);  // MESH, BONE, LIGHT, CAMERA
while(first) {
    name  = first.name;
    first = first.next();
}
```

**To SET an item's position from a generic script**, `param()` / `setParam()` are
read-only and will error. Select the item then call the `Position()` Layout command:

```lscript
SelectItem(item.id);
Position(x, y, z);   // sets position at current frame (frame 0 by default)
```

---

## Channel Access Object Agent (`ca`)

```lscript
val = ca.get(time);   // read channel value
ca.set(value);        // override channel value
name = ca.name;       // channel name string
```

---

## effectedby() — Dependency Declaration

Call in `create()` to ensure correct evaluation order when your script reads
another item's transforms:

```lscript
create: obj
{
    effectedby("MasterNull");
}
```

---

## Scene I/O — load() and save()

Values **must** be saved/loaded in the **exact same order**.

```lscript
load: what, io
{
    if(what == SCENEMODE) {
        myFloat  = number(io.read());
        myInt    = integer(io.read());
        myString = io.read();
    }
}
save: what, io
{
    if(what == SCENEMODE) {
        io.writeln(myFloat);
        io.writeln(myInt);
        io.writeln(myString);
    }
}
```

---

## Layout-Specific UI Controls

```lscript
c1 = ctlallitems("Target", defaultItem);
c2 = ctlmeshitems("Object", defaultMesh);
c3 = ctllightitems("Light", defaultLight);
c4 = ctlcameraitems("Camera", defaultCam);
c5 = ctlchoice("Axis", 1, @"X","Y","Z"@);
```

---

## Layout Commands from Generic Scripts

Layout commands are called **directly as LScript functions** — there is no
`LW_COMMAND()` wrapper (that is an unresolved reference and will error).

```lscript
AddNull("MyNull");
GoToFrame(30);
SaveScene("/path/to/scene.lws");
SelectItem(obj.id);
Clone();
```

Common command names (match the Layout command name exactly, no spaces):
| Action | LScript call |
|--------|-------------|
| Select an item | `SelectItem(id)` |
| Clone selected | `Clone()` |
| Add a null | `AddNull("name")` |
| Go to frame | `GoToFrame(n)` |
| Save scene | `SaveScene(path)` |

---

## Gotchas

1. **Global variables are shared across all instances** of the same script type —
   use `self`-style per-instance storage via lifecycle arguments, not bare globals.
2. `load()` / `save()` are mandatory for any persistent settings.
3. `options()` is called every time the user opens properties — guard with
   `return if !reqpost()`.
4. Always call `setdesc()` in `create()`, after `load()`, and after `options()`.
5. `effectedby()` is required if your script reads another item — missing it
   causes stale data during render.
6. **No `{}` literal for associative arrays** — `myHash = {};` is a parse error
   (`found '{'`). Declare the variable bare (`myHash;`) before first use; LScript
   auto-promotes it to an associative array on the first string-key assignment:

   ```lscript
   // WRONG — parse error
   existingIDs = {};

   // CORRECT — declare bare, then assign
   existingIDs;
   existingIDs["someKey"] = 1;   // promoted to assoc-array here
   ```

   To check for a missing key, compare against `nil`:
   ```lscript
   if(existingIDs[string(item.id)] == nil) { ... }
   ```

8. **No `LW_COMMAND()` wrapper** — `LW_COMMAND("Clone")` gives
   *"Unresolved function reference: LW_COMMAND()"*. Layout commands are called
   **directly as functions**, arguments passed normally:

   ```lscript
   // WRONG
   LW_COMMAND("SelectItem " + obj.id);
   LW_COMMAND("Clone");

   // CORRECT
   SelectItem(obj.id);
   Clone();
   ```

9. **`ctlmeshitems` default must be an Object Agent, not `nil`** — passing `nil`
   leaves the control empty and `getvalue()` returns `nil`. Use `getfirstitem(MESH)`
   as the default *before* `reqbegin`. `getvalue()` returns an **Object Agent
   directly** — do NOT wrap it in `Mesh()` (that causes *"invalid argument 1 type"*):

   ```lscript
   defaultMesh = getfirstitem(MESH);   // before reqbegin
   reqbegin("My Tool");
       c_src = ctlmeshitems("Object", defaultMesh);
   return if !reqpost();
       srcObj = getvalue(c_src);       // Object Agent — use directly
   reqend();
   ```

10. **`param()` / `setParam()` are read-only** — calling `item.setParam(POSITION, ...)`
    gives *"invalid object method setParam()"*. To move an item in a generic script,
    use `SelectItem(item.id)` followed by the `Position(x, y, z)` Layout command.

11. **No `break` in loops** — to exit a `while` early, set the loop variable to
   `nil` (or a falsy value) inside the body:

   ```lscript
   scan = getfirstitem(MESH);
   while(scan)
   {
       if(foundIt(scan)) {
           result = scan;
           scan = nil;   // exits the while on next condition check
       } else {
           scan = scan.next();
       }
   }
   ```

---

## File Placement

Copy `.ls` files to `LightWave/Scripts/Layout/` (macOS) or
`%APPDATA%\NewTek\LightWave\2024\Scripts\Layout\` (Windows).
Run **Edit > Refresh Plugins** in Layout.
