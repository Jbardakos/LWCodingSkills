---
name: lscript-layout
description: >
  Use this skill for any LScript code targeting LightWave Layout. Covers all Layout
  script types: Item Animation (motion), Channel Filter, Generic, Master Class.
  Includes Object Agent methods, scene I/O, load/save scene data, options() UI.
  Trigger when a user asks to write, debug, or extend an LScript (.ls) for Layout
  tasks: motion control, channel constraints, scene automation, or rendering hooks.
---

# LScript — Layout Scripting

## ⚠️ STEP 0: READ THE CORRECT TEMPLATE FIRST ⚠️

Before writing any Layout LScript, read the appropriate template and use it as
the **literal starting point**. Replace all `PLUGIN_NAME` tokens. Fill in `TODO`.

| Task | Template to read |
|------|-----------------|
| Per-frame motion / transform control | `templates/motion_handler.ls` |
| Clamp or modify individual channel values | `templates/channel_filter.ls` |
| One-shot scene automation tool | `templates/generic.ls` |

---

## Script Types

| `@script` | Class | Use |
|-----------|-------|-----|
| `motion` | Item Animation | per-frame transform control |
| `channel` | Channel Filter | single channel clamp/modify |
| `generic` | Generic | one-shot Layout tool |
| `master` | Master Class | scene-global event handler |
| `displacement` | Displacement | per-vertex deformation |
| `shader` | Shader | surface shading |

---

## Lifecycle Functions

```
              motion  channel  generic  master
create          ✓       ✓        —        ✓
destroy         ✓       ✓        —        ✓
process         ✓       ✓        —        ✓
generic()       —       —        ✓        —
options         ✓       ✓        —        ✓
load/save       ✓       ✓        —        ✓
event           —       —        —        ✓
```

---

## Motion Access Object Agent (`ma`)

```lscript
pos = ma.get(POSITION, time);   // <x,y,z> metres
rot = ma.get(ROTATION, time);   // <h,p,b> degrees
scl = ma.get(SCALING,  time);

ma.set(POSITION, <x, y, z>);
ma.set(ROTATION, <h, p, b>);
ma.set(SCALING,  <sx, sy, sz>);
```

Constants: `POSITION`, `ROTATION`, `SCALING`, `PIVOT`, `WORLDPOSITION`

---

## Scene Item Object Agents

```lscript
obj  = Object("ObjectName.lwo");
mesh = Mesh("ObjectName.lwo");
pos  = obj.param(POSITION, time);

// Traverse scene
first = getfirstitem(MESH);  // MESH, BONE, LIGHT, CAMERA
while(first) {
    name  = first.name;
    first = first.next();
}
```

---

## Channel Access Object Agent (`ca`)

```lscript
val = ca.get(time);   // read channel value
ca.set(value);        // override channel value
name = ca.name;       // channel name string
```

---

## effectedby() — Dependency Declaration

Call in `create()` to ensure correct evaluation order when your script reads
another item's transforms:

```lscript
create: obj
{
    effectedby("MasterNull");
}
```

---

## Scene I/O — load() and save()

Values **must** be saved/loaded in the **exact same order**.

```lscript
load: what, io
{
    if(what == SCENEMODE) {
        myFloat  = number(io.read());
        myInt    = integer(io.read());
        myString = io.read();
    }
}
save: what, io
{
    if(what == SCENEMODE) {
        io.writeln(myFloat);
        io.writeln(myInt);
        io.writeln(myString);
    }
}
```

---

## Layout-Specific UI Controls

```lscript
c1 = ctlallitems("Target", defaultItem);
c2 = ctlmeshitems("Object", defaultMesh);
c3 = ctllightitems("Light", defaultLight);
c4 = ctlcameraitems("Camera", defaultCam);
c5 = ctlchoice("Axis", 1, @"X","Y","Z"@);
```

---

## Layout Commands from Generic Scripts

```lscript
LW_COMMAND("AddNull MyNull");
LW_COMMAND("GoToFrame 30");
LW_COMMAND("SaveScene /path/to/scene.lws");
LW_COMMAND("SelectItem " + obj.id);
```

---

## Gotchas

1. **Global variables are shared across all instances** of the same script type —
   use `self`-style per-instance storage via lifecycle arguments, not bare globals.
2. `load()` / `save()` are mandatory for any persistent settings.
3. `options()` is called every time the user opens properties — guard with
   `return if !reqpost()`.
4. Always call `setdesc()` in `create()`, after `load()`, and after `options()`.
5. `effectedby()` is required if your script reads another item — missing it
   causes stale data during render.

---

## File Placement

Copy `.ls` files to `LightWave/Scripts/Layout/` (macOS) or
`%APPDATA%\NewTek\LightWave\2024\Scripts\Layout\` (Windows).
Run **Edit > Refresh Plugins** in Layout.
