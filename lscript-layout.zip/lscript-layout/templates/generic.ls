@version 2.3
@warnings
@script generic
@name PLUGIN_NAME

// ============================================================
// TODO: Replace PLUGIN_NAME above with your script name
// TEMPLATE: Generic Script (Layout)
// One-shot execution — runs once when called from the menu.
// Can access all scene items and fire Layout commands.
// No create/destroy/load/save lifecycle.
// ============================================================

generic
{
    // ---- UI (optional) -------------------------------------
    reqbegin("PLUGIN_NAME");

        // TODO: controls

    return if !reqpost();

        // TODO: read values

    reqend();

    // ---- Scene access --------------------------------------
    // Iterate objects
    // obj = getfirstitem(MESH);
    // while(obj)
    // {
    //     name = obj.name;
    //     pos  = obj.param(POSITION, 0.0);
    //     obj  = obj.next();
    // }

    // ---- Fire Layout commands ------------------------------
    // AddNull("MyNull");
    // SelectItem(obj.id);
    // Clone();
    // GoToFrame(30);

    // TODO: implement your tool logic
}
