@version 2.3
@warnings
@script channel
@name PLUGIN_NAME

// ============================================================
// TODO: Replace PLUGIN_NAME above with your script name
// TEMPLATE: Channel Filter
// Applied to individual channels (Position.X, Rotation.H, etc.)
// Reads and/or overrides channel value at each frame
// ============================================================

// TODO: declare your parameters here
// maxValue = 1.0;

create: channel
{
    // channel = Channel Object Agent for the channel this is applied to
    setdesc("PLUGIN_NAME");
    // TODO: inspect channel.name if needed
}

destroy
{
}

process: ca, frame, time
{
    // ca = Channel Access Object Agent
    // Read current value
    val = ca.get(time);

    // TODO: modify val, e.g.:
    // if(val > maxValue) ca.set(maxValue);
    // if(val < 0)        ca.set(0);
}

options
{
    reqbegin("PLUGIN_NAME");

        // TODO: controls

    return if !reqpost();

        // TODO: read values

    reqend();
    setdesc("PLUGIN_NAME");
}

load: what, io
{
    if(what == SCENEMODE)
    {
        // TODO: io.read() for each saved variable
    }
}

save: what, io
{
    if(what == SCENEMODE)
    {
        // TODO: io.writeln() for each variable
    }
}
