@version 2.3
@warnings
@script motion
@name PLUGIN_NAME

// ============================================================
// TODO: Replace PLUGIN_NAME above with your script name
// TEMPLATE: Item Animation (Motion Handler)
// Applied to: objects, bones, lights, cameras
// Called per-frame during playback and render
// ============================================================

// Global variables — persist across all UDF calls
// TODO: declare your parameters here, e.g.:
// amplitude = 0.5;
// frequency = 1.0;

create: obj
{
    // Called once when script is applied or scene is loaded.
    // obj = the item this instance is applied to (Object Agent).
    setdesc("PLUGIN_NAME");   // label shown in Layout property panel

    // TODO: set defaults, validate scene state
}

destroy
{
    // Called when script is removed or scene is cleared.
    // TODO: cleanup if needed
}

process: ma, frame, time
{
    // Called every frame during playback and render.
    // ma    = Motion Access Object Agent
    // frame = integer frame number
    // time  = float time in seconds

    // Read current transforms
    pos = ma.get(POSITION, time);   // <x, y, z> in metres
    rot = ma.get(ROTATION, time);   // <h, p, b> in degrees
    scl = ma.get(SCALING,  time);   // <sx, sy, sz>

    // TODO: modify transforms, e.g.:
    // pos.y += amplitude * sin(frequency * time * 360);
    // ma.set(POSITION, pos);
}

options
{
    // Called when user double-clicks the script in the property panel.
    reqbegin("PLUGIN_NAME");

        // TODO: controls matching your global variables, e.g.:
        // c1 = ctlnumber("Amplitude", amplitude);
        // c2 = ctlnumber("Frequency", frequency);

    return if !reqpost();

        // TODO: read back
        // amplitude = getvalue(c1);
        // frequency = getvalue(c2);

    reqend();
    setdesc("PLUGIN_NAME");   // TODO: update with current values
}

load: what, io
{
    if(what == SCENEMODE)
    {
        // TODO: read values in the SAME ORDER as save(), e.g.:
        // amplitude = number(io.read());
        // frequency = number(io.read());
    }
}

save: what, io
{
    if(what == SCENEMODE)
    {
        // TODO: write values in the SAME ORDER as load(), e.g.:
        // io.writeln(amplitude);
        // io.writeln(frequency);
    }
}
