# PLUGIN_NAME — LightWave Python Generic Plugin
# TODO: Replace PLUGIN_NAME throughout this file
#
# TEMPLATE: Generic Plugin
# One-shot execution from the Layout menu.
# Full access to scene items and Layout commands.

import lwsdk

class PLUGIN_NAME(lwsdk.IGeneric):
    """
    TODO: Replace docstring with a description of what this plugin does.
    """

    def __init__(self, context):
        super().__init__()
        # TODO: initialise any instance state here

    def process(self, ga):
        """
        ga = LWLayoutGeneric access object.
        This method is called once when the user runs the plugin.
        Return lwsdk.AFUNC_OK on success.
        """
        msg = lwsdk.LWMessageFuncs()

        # ---- Optional: show a simple info dialog ----
        # msg.info("PLUGIN_NAME", "Running...")

        # ---- Access scene items ----
        item_info = lwsdk.LWItemInfo()
        # obj = item_info.first(lwsdk.LWI_OBJECT, lwsdk.LWITEM_NULL)
        # while obj != lwsdk.LWITEM_NULL:
        #     name = item_info.name(obj)
        #     print(name)           # prints to PCore Console
        #     obj = item_info.next(obj)

        # ---- Fire Layout commands ----
        # ga.evaluate(ga.data, "AddNull MyNull")
        # ga.evaluate(ga.data, "GoToFrame 1")

        # TODO: implement your plugin logic

        msg.info("PLUGIN_NAME", "Done.")
        return lwsdk.AFUNC_OK


# ---- Plugin registration — must be named ServerRecord ----
# TODO: replace the string "PLUGIN_NAME" with your plugin name
ServerRecord = [
    (lwsdk.GenericFactory("PLUGIN_NAME", PLUGIN_NAME), lwsdk.ServerRecord),
]
