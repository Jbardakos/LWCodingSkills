# PLUGIN_NAME — LightWave Python Displacement Plugin
# TODO: Replace PLUGIN_NAME throughout this file
#
# TEMPLATE: Displacement Handler
# Called per-vertex per-frame. Modify access.source to displace geometry.

import lwsdk
import math

class PLUGIN_NAME(lwsdk.IDisplacementHandler):
    """
    TODO: Replace docstring with a description of what this plugin does.
    """

    def __init__(self, context):
        super().__init__()
        # TODO: default parameter values
        # self.amplitude = 0.1
        # self.frequency = 1.0

    def flags(self):
        # Choose coordinate space for displacement:
        #   LWDMF_WORLD       — world space (after object motion)
        #   LWDMF_BEFOREBONES — object space before bone deformation
        #   LWDMF_AFTERMORPH  — after morph targets
        #   LWDMF_LAST        — after all deformations including subdivision
        return lwsdk.LWDMF_WORLD

    def evaluate(self, instance, access):
        """
        Called for every vertex at every frame.
        access.source  — mutable LWDVector [x, y, z] in selected space
        access.oPos    — original position (read-only)
        access.point   — LWPntID
        access.info    — LWMeshInfo for the object
        """
        # TODO: compute displacement and add to access.source, e.g.:
        # x = access.source[0]
        # offset = self.amplitude * math.sin(self.frequency * x)
        # access.source[1] += offset
        pass

    def describe(self):
        # Short string shown in Layout property panel
        return "PLUGIN_NAME"   # TODO: include key param values


# ---- Plugin registration ----
ServerRecord = [
    (lwsdk.DisplacementHandlerFactory("PLUGIN_NAME", PLUGIN_NAME),
     lwsdk.ServerRecord),
]
