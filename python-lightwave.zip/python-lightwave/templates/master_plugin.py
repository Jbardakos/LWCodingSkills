# PLUGIN_NAME — LightWave Python Master Handler Plugin
# TODO: Replace PLUGIN_NAME throughout this file
#
# TEMPLATE: Master Handler
# Scene-global plugin. Receives all Layout events.
# Persists across scene clears (if save() is omitted).

import lwsdk

class PLUGIN_NAME(lwsdk.IMasterHandler):
    """
    TODO: Replace docstring with a description of what this plugin does.
    """

    def __init__(self, context):
        super().__init__()
        # TODO: initialise instance state

    def flags(self):
        # Return LWMAST_SCENE to receive scene events
        # Return LWMAST_LAYOUT for Layout-type (survives scene clear)
        return lwsdk.LWMAST_SCENE

    def event(self, event_code):
        """
        Called when Layout events occur.
        Common event codes:
            lwsdk.LWEVNT_COMMAND  — a command was issued
            lwsdk.LWEVNT_TIME     — time/frame changed
            lwsdk.LWEVNT_SELECT   — selection changed
        """
        # TODO: react to events, e.g.:
        # if event_code == lwsdk.LWEVNT_COMMAND:
        #     print("Command issued")
        pass

    def process(self, ma, frame, time):
        """
        Called every frame during playback and render.
        ma    = scene-level Motion Access object
        frame = current frame (integer)
        time  = current time in seconds (float)
        """
        # TODO: per-frame logic
        return lwsdk.AFUNC_OK

    def describe(self):
        return "PLUGIN_NAME"


# ---- Plugin registration ----
ServerRecord = [
    (lwsdk.MasterHandlerFactory("PLUGIN_NAME", PLUGIN_NAME),
     lwsdk.ServerRecord),
]
