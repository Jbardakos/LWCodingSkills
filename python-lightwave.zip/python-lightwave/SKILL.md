---
name: python-lightwave
description: >
  Use this skill for Python code targeting LightWave's embedded Python environment
  (PCore / lwsdk). Covers handler class structure, lwsdk globals, Layout command
  execution, PCore console, and plugin registration. Trigger when a user asks to
  write, debug, or extend a Python plugin or script for LightWave Layout.
---

# Python — LightWave Plugin Scripting

## ⚠️ STEP 0: READ THE CORRECT TEMPLATE FIRST ⚠️

Before writing any Python plugin, read the appropriate template and use it as
the **literal starting point**. Replace all `PLUGIN_NAME` tokens. Fill in `TODO`.

| Task | Template to read |
|------|-----------------|
| One-shot Layout tool or scene automation | `templates/generic_plugin.py` |
| Per-vertex geometry deformation | `templates/displacement_plugin.py` |
| Scene-global event handler | `templates/master_plugin.py` |

---

## Overview

LightWave embeds Python 3.x via **PCore**. The `lwsdk` module provides SWIG-wrapped
bindings to the same C SDK used by compiled plugins. Python plugin files (`.py`) are
loaded and registered exactly like `.p` files.

`lwsdk` is **only available inside LightWave** — it cannot be installed via pip.

---

## Handler Base Classes

| Base class | Layout equivalent | Use |
|-----------|-------------------|-----|
| `lwsdk.IGeneric` | generic | One-shot tool |
| `lwsdk.IMasterHandler` | master | Scene-global events |
| `lwsdk.IDisplacementHandler` | displacement | Per-vertex deform |
| `lwsdk.IMeshDeformer` | meshdeformer | Modern deform (LW2018+) |
| `lwsdk.IItemMotionHandler` | motion | Per-frame transforms |
| `lwsdk.IChannelHandler` | channel | Channel value filter |
| `lwsdk.IImageFilterHandler` | imagefilter | Post-render buffer |
| `lwsdk.IEnvironmentHandler` | environment | Backdrop/sky |
| `lwsdk.IShaderHandler` | shader | Surface shading |

---

## Plugin Registration — Always Required

```python
ServerRecord = [
    (lwsdk.GenericFactory("MyPlugin_Name", MyClass), lwsdk.ServerRecord),
]
```

Factory function matches the class:
- Generic → `GenericFactory`
- Master → `MasterHandlerFactory`
- Displacement → `DisplacementHandlerFactory`
- Motion → `ItemMotionHandlerFactory`

---

## Common lwsdk Globals

```python
# Messaging
msg = lwsdk.LWMessageFuncs()
msg.info("Title", "Detail")
msg.error("Title", "Detail")

# Scene info
si = lwsdk.LWSceneInfo()
fps   = si.framesPerSecond
start = si.frameStart
end   = si.frameEnd

# Item traversal
ii  = lwsdk.LWItemInfo()
obj = ii.first(lwsdk.LWI_OBJECT, lwsdk.LWITEM_NULL)
while obj != lwsdk.LWITEM_NULL:
    print(ii.name(obj))    # goes to PCore Console
    obj = ii.next(obj)
```

Item type constants: `lwsdk.LWI_OBJECT`, `lwsdk.LWI_LIGHT`,
`lwsdk.LWI_CAMERA`, `lwsdk.LWI_BONE`

---

## Displacement evaluate() — Key Points

```python
def evaluate(self, instance, access):
    # access.source   — mutable [x, y, z] — modify in-place
    # access.oPos     — original position, read-only
    # access.point    — LWPntID
    # access.info     — LWMeshInfo

    # Modify source directly:
    access.source[1] += 0.1    # move Y up
    # Do NOT replace access.source with a new object
```

Displacement flags (return from `flags()`):
`LWDMF_WORLD`, `LWDMF_BEFOREBONES`, `LWDMF_AFTERMORPH`, `LWDMF_LAST`

---

## Motion Handler per-frame access

```python
def process(self, ma, frame, time):
    pos = ma.get(lwsdk.LWIP_POSITION, time)   # tuple (x, y, z)
    x, y, z = pos
    ma.set(lwsdk.LWIP_POSITION, (x, y + 0.1 * time, z))
```

---

## Layout Commands from Generic

```python
def process(self, ga):
    ga.evaluate(ga.data, "AddNull TestNull")
    ga.evaluate(ga.data, "GoToFrame 1")
    ga.evaluate(ga.data, "SaveScene /tmp/out.lws")
    return lwsdk.AFUNC_OK
```

---

## Preferences

```python
prefs = lwsdk.LWPreferenceSystem()
prefs.setString("/MyPlugin/key", "value")
prefs.setInt   ("/MyPlugin/count", 5)
prefs.setFloat ("/MyPlugin/scale", 1.5)

val = prefs.getString("/MyPlugin/key")
```

---

## PCore Console

```python
print("message")       # goes to PCore Console automatically
import sys
sys.stderr.write("error\n")   # also routed to Console
```

Open console from Layout: `Window > Python Console`
or Layout command: `OpenPCoreConsole`

---

## File Placement

Copy `.py` to `LightWave/Plugins/` then **Edit > Refresh Plugins** in Layout.
Generics appear under **Utilities > Generics**; other classes under their respective menus.

---

## Gotchas

1. **`ServerRecord` must be module-level** with exactly that name.
2. **Factory names must be globally unique** — use a studio prefix.
3. **`print()` goes to PCore Console**, not terminal.
4. **Handler methods must return `lwsdk.AFUNC_OK`** — returning `None` is treated as failure.
5. **LWDVector in `evaluate()` is mutable** — assign to indices, do not replace the object.
6. **No persistent globals between calls** — store all state as `self.*` set in `__init__()`.
7. **`lwsdk` is not importable outside LightWave** — no unit testing with regular Python.
