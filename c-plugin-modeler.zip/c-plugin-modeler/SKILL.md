---
name: c-plugin-modeler
description: >
  Use this skill for compiled C/C++ plugins (.p files) targeting LightWave Modeler.
  Covers CommandSequence, MeshDataEdit, and the INTERACTIVE MeshEditTool class
  (live draggable viewport handles); MeshEditOp functions; ServerRecord; GlobalFunc;
  XPanels UI; macOS and Windows build. Trigger when a user asks to write, build, or
  debug a compiled Modeler plugin in C or C++ — including interactive tools with
  click-drag handles.
---

# C / C++ Plugin — LightWave Modeler

## ⚠️ STEP 0: READ THE CORRECT TEMPLATE FIRST ⚠️

Before writing any plugin code, read the appropriate template and use it as
the **literal starting point**. Replace `PLUGIN_NAME`. Fill in `TODO` sections.

| Task | Template to read |
|------|-----------------|
| Send Modeler command strings | `templates/commandseq_plugin.c` |
| Create or modify geometry at point/poly level (one-shot) | `templates/meshedit_plugin.c` |
| **Interactive tool with live draggable handles** | `templates/meshedittool_plugin.c` |
| macOS build script | `templates/build_mac.sh` |

---

## Plugin Classes

| Class constant | Header | Use |
|----------------|--------|-----|
| `LWMODCOMMAND_CLASS` | `lwcmdseq.h` | Send command strings to Modeler |
| `LWMESHEDIT_CLASS` | `lwmeshedt.h` | One-shot point/polygon creation & modification (MeshDataEdit) |
| `LWMESHEDITTOOL_CLASS` | `lwmodtool.h` | **Interactive tool: live, draggable viewport handles** |

⚠️ The interactive class is literally `"MeshEditTool"` →
`#define LWMESHEDITTOOL_CLASS "MeshEditTool"` / `LWMESHEDITTOOL_VERSION 7`,
declared in **`lwmodtool.h`** (NOT `lwmeshedt.h`, and there is no
`LWMESHTOOL_CLASS`). LScript cannot create live handles — this must be a
compiled `.p`.

---

## Required Headers

```c
#include <lwserver.h>    // every plugin — ServerRecord, XCALL_, AFUNC_*
#include <lwcmdseq.h>    // CommandSequence
#include <lwmeshedt.h>   // MeshEditOp (addPoint/addFace/setLayer/...), MeshDataEdit
#include <lwtool.h>      // interactive: LWToolFuncs, LWToolEvent, LWWireDrawAccess, LWT_*
#include <lwmodtool.h>   // interactive: LWMeshEditTool, LWMESHEDITTOOL_CLASS/_VERSION
#include <lwxpanel.h>    // XPanels UI
#include <lwmessage.h>   // Message dialogs
```

SDK include path (real location on macOS — verify `ls "$SDK"/lwserver.h`):
```
/Applications/LightWaveDigital/LightWave3D_2024.2.0/sdk/lwsdk2024.2/include
```
(The often-quoted `/Users/mac/Applications/Lightwave3d_2024.2.0/sdk/include`
does not exist on a normal install — the headers are inside the app bundle.)

---

## Activation Function Signatures

```c
// CommandSequence
XCALL_( int ) Activate( int version, GlobalFunc *global,
                        LWModCommand *local, void *serverData );

// MeshDataEdit
XCALL_( int ) Activate( int version, GlobalFunc *global,
                        MeshEditBegin *begin, void *serverData );

// Interactive MeshEditTool — the 3rd param is void* in the ActivateFunc
// typedef; cast it. (Declaring it as LWMeshEditTool* directly triggers an
// incompatible-function-pointer-type error in ServerDesc.)
XCALL_( int ) Activate( int version, GlobalFunc *global,
                        void *localData, void *serverData )
{
    LWMeshEditTool *local = (LWMeshEditTool *)localData;
    if ( version != LWMESHEDITTOOL_VERSION ) return AFUNC_BADVERSION;
    ...
}
```

Always check version first and `return AFUNC_BADVERSION` on mismatch.

---

## ServerDesc — Plugin Registry

Every `.p` file must export this array:
```c
ServerRecord ServerDesc[] = {
    { LWMESHEDITTOOL_CLASS, "MyPlugin_Name", Activate },
    { NULL }   // sentinel required
};
```

---

## Interactive Tool (MeshEditTool) — live draggable handles

The activation function only **registers callbacks**; the tool then stays live,
with Modeler calling those callbacks on every mouse move / panel change until the
tool is dropped. Fill `LWMeshEditTool`:

```c
local->instance = myData;        // your instance struct
local->tool     = &myToolFuncs;  // LWToolFuncs (see below)
local->test     = Test;          // int  (LWInstance)        -> LWT_TEST_*
local->build    = Build;         // LWError (LWInstance, MeshEditOp*)
local->end      = End;           // void (LWInstance, int keep)
```

`LWToolFuncs` (in `lwtool.h`) — the handle + drawing machinery:

```c
void          (*done)  (LWInstance);                              // free instance
void          (*draw)  (LWInstance, LWWireDrawAccess*);           // draw the tool
LWCStringUTF8 (*help)  (LWInstance, LWToolEvent*);                // status text
int           (*dirty) (LWInstance);                              // LWT_DIRTY_* bits
int           (*count) (LWInstance, LWToolEvent*);                // # framework handles
int           (*handle)(LWInstance, LWToolEvent*, int i, LWDVector pos); // handle pos
int           (*start) (LWInstance, LWToolEvent*);                // first mouse-down
int           (*adjust)(LWInstance, LWToolEvent*, int i);         // framework handle drag
int           (*down)  (LWInstance, LWToolEvent*);                // raw mouse-down
void          (*move)  (LWInstance, LWToolEvent*);                // raw drag
void          (*up)    (LWInstance, LWToolEvent*);                // raw mouse-up
void          (*event) (LWInstance, int code);                    // LWT_EVENT_*
LWXPanelID    (*panel) (LWInstance);                              // numeric panel
```

**Two ways to drive handles:**
- *Framework-managed:* return N from `count()`, report each handle's position in
  `handle()`, move it in `adjust()`. Modeler draws & picks them in every viewport
  automatically. Simplest; gives the orange/blue handles.
- *Raw:* return `count()==0` and do your own picking in `down()/move()/up()`
  (needed for multi-button behaviour, click-to-add, split, branch, etc.). You then
  draw and pick handles yourself — see the coordinate gotchas below.

**The commit (preview→bake) cycle** is the heart of it:

| `test()` returns | Meaning |
|---|---|
| `LWT_TEST_NOTHING` | preview is current, do nothing |
| `LWT_TEST_UPDATE`  | geometry changed → Modeler calls `build()` to regenerate the **live preview** |
| `LWT_TEST_ACCEPT`  | bake the last preview into the real mesh |
| `LWT_TEST_REJECT`  | discard the preview |

`build()` regenerates a **live preview** — never call `op->done()` there; Modeler
owns commit/reject via the `test()` code. An "Apply"/"Make X" button simply makes
`test()` return `LWT_TEST_ACCEPT`. On drop (`LWT_EVENT_DROP` in `event()`) return
`ACCEPT` to bake like native primitives, or `REJECT` to require the button.

`dirty()` returns `LWT_DIRTY_WIREFRAME | LWT_DIRTY_HELPTEXT` when redraw is needed.
The canonical idiom is to set a flag on change and **clear it at the end of
`draw()`** (this is what the SDK `capsule` sample does and it redraws all
viewports fine — don't "fix" it).

### Coordinate gotchas for RAW handle picking (these bite hard)

Read `LWToolEvent` carefully (`lwtool.h`). All positions are **model space on the
current view plane**; the field `axis` is the view depth direction (everything
under the cursor lies along it). Then:

1. **`deltaSnap`/`deltaRaw` are CUMULATIVE** — measured from the initial
   mouse-DOWN to the current event, NOT since the previous `move()`. Adding it
   every `move()` makes handles accelerate/run away (and explode when the window
   is resized, which re-fires move events). Use absolute positioning instead.
2. **`posSnap` lies on the view plane** — assigning it straight into a 3D point
   *flattens that point onto the current view's plane*, destroying the depth it
   had from another viewport. To stay consistent across views, move only **in the
   view plane**: keep the point's component along `axis`, replace the rest:
   ```c
   // node <- cursor in-plane, keep node's own depth along the view axis
   double dn = dot(node,axis), dc = dot(cursor,axis), s = dn - dc;
   node[k] = cursor[k] + s*axis[k];   // k = 0..2
   ```
   This is absolute (no accumulation) → also immune to window resize.
3. **Pick perpendicular to `axis`** — measure handle-vs-cursor distance with the
   depth component removed, so a handle off the current construction plane is
   still grabbable from any viewport:
   ```c
   v_sub(p,q,d); proj = dot(d,axis); d -= proj*axis; dist = len(d);
   ```
4. `axis` can be near-zero in odd cases — normalise a copy, fall back to (0,0,1).

---

## MeshEditOp Key Functions

```c
// Geometry creation (state = op->state)
LWPntID  addPoint ( state, double *xyz )
LWPolID  addFace  ( state, const char *surf, int n, const LWPntID * )   // n-gon
LWPolID  addCurve ( state, const char *surf, int n, const LWPntID *, int flags ) // CURVE

// Layers — op->layerNum is the working layer index; switch to emit on another
int      setLayer ( state, int layerNum )   // e.g. setLayer(state, op->layerNum + 1)
int      advanceLayer( state )

// Scanning (iteration)
EDError  polyScan ( state, EDPolyScanFunc*, void *userdata, EltOpLayer )
EDError  pointScan( state, EDPointScanFunc*, void *userdata, EltOpLayer )

// One-shot edit modification (MeshDataEdit class)
EDError  pntMove  ( state, LWPntID, const double *newPos )
EDError  polSurf  ( state, LWPolID, const char *surfName )

// One-shot commit (MeshDataEdit ONLY — NOT inside an interactive build())
void     done     ( state, EDError, int selm )  // EDERR_NONE commit / EDERR_USERABORT cancel
```

To emit a tube's core/spine onto the next layer from an interactive build:
`setLayer(state, op->layerNum+1)` → add points/curve → `setLayer(state, op->layerNum)`
to restore. Guard `op->setLayer` for NULL and check the returned point IDs.

---

## Scan Callback Pattern

```c
static EDError
ScanPoly( void *userdata, const EDPolygonInfo *info )
{
    // info->pol, info->numPnts, info->points[], info->type
    return EDERR_NONE;
}
op->polyScan( op->state, ScanPoly, myData, OPLYR_FG );
```

---

## XPanels UI

**Modal / one-shot** (CommandSequence, MeshDataEdit): `create → formSet → post →
formGet → destroy`.

```c
static LWXPanelHint hints[] = {
    XpLABEL(0, "My Plugin"),
    XpF64(CTRL_SCALE, "Scale"),
    XpINT(CTRL_SEGS,  "Segments"),
    XpEND
};
LWXPanelFuncs *xpanf = global( LWXPANELFUNCS_GLOBAL, GFUSE_TRANSIENT );
LWXPanelID panel = xpanf->create( LWXP_VIEW, hints );
xpanf->formSet( panel, CTRL_SCALE, &myDouble );
int ok = xpanf->post( panel );
if (ok) xpanf->formGet( panel, CTRL_SCALE, &myDouble );
xpanf->destroy( panel );
```

**Interactive tool numeric panel** (`LWXP_VIEW`) is different — it is *attached*
to the live tool via get/set callbacks, not posted:

```c
LWXPanelControl ctl[] = { {ID_X,"Label","distance"}, ... {0} };
LWXPanelDataDesc dd[] = { {ID_X,"Label","float"},    ... {0} };
LWXPanelHint hint[]   = { XpLABEL(0,"My Tool"), XpMIN(ID_SEG,1),
                          XpBUTNOTIFY(ID_APPLY, OnApply), XpEND };
panel = xpanf->create( LWXP_VIEW, ctl );
xpanf->describe( panel, dd, PanelGet, PanelSet );  // get/set callbacks
xpanf->hint( panel, 0, hint );
xpanf->viewInst( panel, inst );
xpanf->setData( panel, 0, inst );                   // so button cb can fetch it
```

Callback signatures must match the headers exactly or you get
incompatible-function-pointer errors:
```c
void *          PanelGet( void *inst, unsigned int vid );               // LWXPanelGetFunc
LWXPRefreshCode PanelSet( void *inst, unsigned int vid, void *value );  // LWXPanelSetFunc
void            OnApply ( LWXPanelID pan, int cid );                    // LWXPanelBtnClickFunc
```
A `"vButton"` control + `XpBUTNOTIFY(id, fn)` gives a clickable button; the cb
fetches the instance with `xpanf->getData(pan, 0)`.

---

## Messages

```c
LWMessageFuncs *msg = global( LWMESSAGEFUNCS_GLOBAL, GFUSE_TRANSIENT );
msg->info   ( "Title", "Detail or NULL" );
msg->error  ( "Title", "Detail or NULL" );
```

---

## macOS Build

```bash
clang -dynamiclib \
      -D_MACOS \
      -I"/Applications/LightWaveDigital/LightWave3D_2024.2.0/sdk/lwsdk2024.2/include" \
      -o MyPlugin.p MyPlugin.c \
      -lm -framework CoreFoundation \
      -arch arm64 -arch x86_64
xattr -d com.apple.quarantine MyPlugin.p   # clear Gatekeeper quarantine
```

`-D_MACOS` is **mandatory** (see Gotchas). Confirm the result is universal:
`lipo -archs MyPlugin.p` → `x86_64 arm64`.

---

## Gotchas

1. **`-D_MACOS` is required on macOS.** `lwserver.h` only defines `XCALL_(t)`
   under `_MSWIN`/`_LINUX`/`_MACOS`; clang predefines none. Without it,
   `XCALL_(int)` before `Activate()` fails to expand → "expected function body
   after function declarator". Header/path mismatches like this are the usual
   reason a "written-from-docs" plugin won't compile — reconcile against the real
   headers.
2. **Interactive Activate takes `void*` for the local.** Cast to
   `LWMeshEditTool*` inside; declaring it directly breaks the `ActivateFunc`
   pointer type used by `ServerDesc`.
3. **`build()` is a live preview — never call `op->done()` there.** Commit/reject
   is driven by `test()`'s return code. For one-shot **MeshDataEdit**, the
   opposite holds: `op->done()` must **always** be called, even on error — pass
   `EDERR_USERABORT` to cancel cleanly.
4. **`deltaSnap` is cumulative from mouse-down**, not per-move — see interactive
   coordinate gotchas. Use absolute in-plane positioning.
5. **`posSnap` flattens depth onto the view plane** — move in-plane and keep the
   `axis` component to stay consistent across viewports & window resizes.
6. **Polygon winding / normals.** A polygon's visible (front) normal follows the
   geometric normal `(P1-P0)×(P2-P0)` — make it point *outward*. Swept tube bodies
   get this from the standard ring winding; **caps need care**: a cap/dome built
   with one fixed winding for both ends comes out correct at one end and
   inside-out at the other, because the ring-frame handedness flips. Pick cap
   winding from `sign(dot(R×U, Tout))` (cap axis vs ring frame). A dark /
   inside-out cap is a flipped winding, not a Modeler bug.
7. **Version check must be first** — `AFUNC_BADVERSION` on mismatch.
8. **`GFUSE_TRANSIENT` globals are only valid during activation** — grab the func
   table you need (e.g. `LWXPanelFuncs`) and store that pointer; don't re-query
   later.
9. **No C++ exceptions across the LightWave boundary** — catch before returning.
10. **Universal Binary** — always `-arch arm64 -arch x86_64` so the `.p` loads
    whether Modeler runs native or under Rosetta.
11. **Reload after rebuild** — Modeler caches loaded `.p` files; restart Modeler
    (or re-`Add Plugins`) to pick up a new build.
12. **Surface names are language-encoded** — use plain ASCII surface names to
    avoid encoding bugs.
