---
name: c-plugin-modeler
description: >
  Use this skill for compiled C/C++ plugins (.p files) targeting LightWave Modeler.
  Covers CommandSequence, MeshDataEdit classes; MeshEditOp functions; ServerRecord;
  GlobalFunc; XPanels UI; macOS and Windows build. Trigger when a user asks to write,
  build, or debug a compiled Modeler plugin in C or C++.
---

# C / C++ Plugin — LightWave Modeler

## ⚠️ STEP 0: READ THE CORRECT TEMPLATE FIRST ⚠️

Before writing any plugin code, read the appropriate template and use it as
the **literal starting point**. Replace `PLUGIN_NAME`. Fill in `TODO` sections.

| Task | Template to read |
|------|-----------------|
| Send Modeler command strings | `templates/commandseq_plugin.c` |
| Create or modify geometry at point/poly level | `templates/meshedit_plugin.c` |
| macOS build script | `templates/build_mac.sh` |

---

## Plugin Classes

| Class constant | Header | Use |
|----------------|--------|-----|
| `LWMODCOMMAND_CLASS` | `lwcmdseq.h` | Send command strings to Modeler |
| `LWMESHEDIT_CLASS` | `lwmeshedt.h` | Direct point/polygon creation and modification |
| `LWMESHTOOL_CLASS` | `lwmeshedt.h` | Interactive tool with viewport drag/feedback |

---

## Required Headers

```c
#include <lwserver.h>    // every plugin — ServerRecord, XCALL_, AFUNC_*
#include <lwcmdseq.h>    // CommandSequence
#include <lwmeshedt.h>   // MeshDataEdit
#include <lwxpanel.h>    // XPanels UI
#include <lwmessage.h>   // Message dialogs
```

SDK path: `/Users/mac/Applications/Lightwave3d_2024.2.0/sdk/include/`

---

## Activation Function Signatures

```c
// CommandSequence
XCALL_( int ) Activate( int version, GlobalFunc *global,
                        LWModCommand *local, void *serverData );

// MeshDataEdit
XCALL_( int ) Activate( int version, GlobalFunc *global,
                        MeshEditBegin *begin, void *serverData );
```

Always check version first:
```c
if ( version != LWMODCOMMAND_VERSION ) return AFUNC_BADVERSION;
// or
if ( version != LWMESHEDIT_VERSION  ) return AFUNC_BADVERSION;
```

---

## ServerDesc — Plugin Registry

Every `.p` file must export this array:
```c
ServerRecord ServerDesc[] = {
    { LWMODCOMMAND_CLASS, "MyPlugin_Name", Activate },
    { NULL }   // sentinel required
};
```

---

## MeshEditOp Key Functions

```c
// Creation
LWPntID  addPoint ( state, double *xyz )
LWPolID  addFace  ( state, const char *surf, int n, const LWPntID * )
EDError  addQuad  ( state, p0, p1, p2, p3 )
EDError  addTri   ( state, p0, p1, p2 )

// Scanning (iteration)
EDError  polyScan ( state, EDPolyScanFunc*, void *userdata, EltOpLayer )
EDError  pointScan( state, EDPointScanFunc*, void *userdata, EltOpLayer )

// Modification
EDError  pntMove  ( state, LWPntID, const double *newPos )
EDError  polSurf  ( state, LWPolID, const char *surfName )
EDError  remPoint ( state, LWPntID )
EDError  remPoly  ( state, LWPolID )

// Commit
void     done     ( state, EDError, int selm )
// Use EDERR_NONE to commit, EDERR_USERABORT to cancel
```

Layer constants: `OPLYR_FG`, `OPLYR_BG`, `OPLYR_ALL`

---

## Scan Callback Pattern

```c
static EDError
ScanPoly( void *userdata, const EDPolygonInfo *info )
{
    // info->pol, info->numPnts, info->points[], info->type
    return EDERR_NONE;
}
// Usage:
op->polyScan( op->state, ScanPoly, myData, OPLYR_FG );
```

---

## XPanels UI

```c
static LWXPanelHint hints[] = {
    XpLABEL(0, "My Plugin"),
    XpF64(CTRL_SCALE, "Scale"),
    XpINT(CTRL_SEGS,  "Segments"),
    XpEND
};
LWXPanelFuncs *xpanf = global( LWXPANELFUNCS_GLOBAL, GFUSE_TRANSIENT );
LWXPanelID panel = xpanf->create( LWXP_VIEW, hints );
xpanf->formSet( panel, CTRL_SCALE, &myDouble );
int ok = xpanf->post( panel );
if (ok) xpanf->formGet( panel, CTRL_SCALE, &myDouble );
xpanf->destroy( panel );
```

---

## Messages

```c
LWMessageFuncs *msg = global( LWMESSAGEFUNCS_GLOBAL, GFUSE_TRANSIENT );
msg->info   ( "Title", "Detail or NULL" );
msg->error  ( "Title", "Detail or NULL" );
msg->warning( "Title", "Detail or NULL" );
```

---

## macOS Build

```bash
clang -dynamiclib \
      -I"/Users/mac/Applications/Lightwave3d_2024.2.0/sdk/include" \
      -o MyPlugin.p MyPlugin.c \
      -lm -framework CoreFoundation \
      -arch arm64 -arch x86_64
```

Clear Gatekeeper quarantine after build:
```bash
xattr -d com.apple.quarantine MyPlugin.p
```

---

## Gotchas

1. **Version check must be first** — return `AFUNC_BADVERSION` immediately if mismatch.
2. **`op->done()` must always be called** even on error — use `EDERR_USERABORT` to cancel.
3. **Surface names are language-encoded** — use plain ASCII to avoid encoding bugs.
4. **Polygon winding** — counter-clockwise when viewed from outside for correct normals.
5. **No C++ exceptions across LightWave boundary** — catch before returning from callbacks.
6. **`GFUSE_TRANSIENT` globals are only valid during the activation call** — do not store.
7. **Universal Binary** — always compile with `-arch arm64 -arch x86_64` on macOS.
