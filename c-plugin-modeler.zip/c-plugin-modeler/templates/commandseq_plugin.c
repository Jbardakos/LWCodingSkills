/*
 * PLUGIN_NAME — LightWave Modeler CommandSequence Plugin
 * TODO: Replace PLUGIN_NAME throughout this file
 *
 * TEMPLATE: CommandSequence (.p plugin)
 * Drives Modeler by sending command strings.
 * Use for: automating existing Modeler tools, batch ops.
 */

#include <lwserver.h>
#include <lwcmdseq.h>
#include <lwxpanel.h>
#include <lwmessage.h>
#include <stdio.h>
#include <string.h>

/* ---- XPanel control IDs (arbitrary, must be unique per panel) ---- */
/* TODO: add your control IDs, e.g.:
   #define CTRL_SCALE   1
   #define CTRL_SEGS    2
*/

/* ---- Plugin state (settings) ------------------------------------ */
/* TODO: define a settings struct, e.g.:
typedef struct {
    double scale;
    int    segments;
} Settings;
static Settings settings = { 1.0, 3 };
*/

/* ---- UI helper -------------------------------------------------- */
static int
ShowPanel( GlobalFunc *global )
{
    LWXPanelFuncs *xpanf = global( LWXPANELFUNCS_GLOBAL, GFUSE_TRANSIENT );
    if ( !xpanf ) return 1;   /* no UI — proceed with defaults */

    /* TODO: define hints array, e.g.:
    static LWXPanelHint hints[] = {
        XpLABEL(0,          "PLUGIN_NAME"),
        XpF64  (CTRL_SCALE, "Scale"),
        XpINT  (CTRL_SEGS,  "Segments"),
        XpEND
    };
    LWXPanelID panel = xpanf->create( LWXP_VIEW, hints );
    if ( !panel ) return 0;
    xpanf->formSet( panel, CTRL_SCALE, &settings.scale );
    xpanf->formSet( panel, CTRL_SEGS,  &settings.segments );
    int ok = xpanf->post( panel );
    if ( ok ) {
        xpanf->formGet( panel, CTRL_SCALE, &settings.scale );
        xpanf->formGet( panel, CTRL_SEGS,  &settings.segments );
    }
    xpanf->destroy( panel );
    return ok;
    */

    return 1;   /* TODO: remove this line when panel code is added */
}

/* ---- Activation function ---------------------------------------- */
XCALL_( int )
Activate( int version, GlobalFunc *global,
          LWModCommand *local, void *serverData )
{
    char cmd[256];

    if ( version != LWMODCOMMAND_VERSION )
        return AFUNC_BADVERSION;

    /* Show UI — return if cancelled */
    if ( !ShowPanel( global ) )
        return AFUNC_OK;

    /* ---- Send commands to Modeler ---- */
    /* TODO: build and send command strings, e.g.:
    sprintf( cmd, "MAKEBOX <-%.4f -%.4f -%.4f> <%.4f %.4f %.4f> <%d %d %d>",
             settings.scale * 0.5, settings.scale * 0.5, settings.scale * 0.5,
             settings.scale * 0.5, settings.scale * 0.5, settings.scale * 0.5,
             settings.segments, settings.segments, settings.segments );
    local->evaluate( local->data, cmd );
    */

    return AFUNC_OK;
}

/* ---- Server record — LightWave plugin registry ------------------ */
/* TODO: replace "PLUGIN_NAME" string with your actual plugin name  */
ServerRecord ServerDesc[] = {
    { LWMODCOMMAND_CLASS, "PLUGIN_NAME", Activate },
    { NULL }
};
