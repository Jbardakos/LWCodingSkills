/*
 * PLUGIN_NAME — LightWave Modeler MeshDataEdit Plugin
 * TODO: Replace PLUGIN_NAME throughout this file
 *
 * TEMPLATE: MeshDataEdit (.p plugin)
 * Direct access to point and polygon data.
 * Use for: procedural geometry, mesh analysis, point modification.
 */

#include <lwserver.h>
#include <lwmeshedt.h>
#include <lwxpanel.h>
#include <lwmessage.h>
#include <stdio.h>
#include <math.h>

/* ---- XPanel control IDs ----------------------------------------- */
/* TODO: define control IDs, e.g.:
   #define CTRL_RADIUS  1
   #define CTRL_SIDES   2
*/

/* ---- Settings ---------------------------------------------------- */
/* TODO: define settings struct, e.g.:
typedef struct {
    double radius;
    int    sides;
} Settings;
static Settings settings = { 0.5, 8 };
*/

/* ---- Polygon scan callback -------------------------------------- */
/*
static EDError
ScanPolygon( void *userdata, const EDPolygonInfo *info )
{
    MeshEditOp *op = (MeshEditOp *)userdata;

    // info->pol        = LWPolID
    // info->numPnts    = vertex count
    // info->points[]   = array of LWPntID
    // info->type       = LWPOLTYPE_FACE, etc.

    // TODO: process polygon

    return EDERR_NONE;
}
*/

/* ---- Point scan callback ---------------------------------------- */
/*
static EDError
ScanPoint( void *userdata, const EDPointInfo *info )
{
    // info->pnt           = LWPntID
    // info->position[3]   = double xyz in object space

    // TODO: process point

    return EDERR_NONE;
}
*/

/* ---- Activation function ---------------------------------------- */
XCALL_( int )
Activate( int version, GlobalFunc *global,
          MeshEditBegin *begin, void *serverData )
{
    MeshEditOp *op;

    if ( version != LWMESHEDIT_VERSION )
        return AFUNC_BADVERSION;

    /* TODO: show UI panel here (same pattern as commandseq_plugin.c) */

    /* Begin mesh edit
     * args: per-point user data size, per-polygon user data size, selection mode
     * OPSEL_USER  = respect current user selection
     * OPSEL_DIRECT = all geometry regardless of selection */
    op = begin( 0, 0, OPSEL_USER );
    if ( !op ) return AFUNC_FAILED;

    /* ---- Option A: Create new geometry ---- */
    /*
    double pos[3];
    LWPntID pts[4];

    pos[0] = -0.5; pos[1] = 0.0; pos[2] = -0.5;
    pts[0] = op->addPoint( op->state, pos );
    pos[0] =  0.5;
    pts[1] = op->addPoint( op->state, pos );
    pos[0] =  0.5; pos[2] =  0.5;
    pts[2] = op->addPoint( op->state, pos );
    pos[0] = -0.5;
    pts[3] = op->addPoint( op->state, pos );

    op->addFace( op->state, "Default", 4, pts );
    */

    /* ---- Option B: Scan and modify existing geometry ---- */
    /*
    op->polyScan ( op->state, ScanPolygon, op, OPLYR_FG );
    op->pointScan( op->state, ScanPoint,   op, OPLYR_FG );
    */

    /* TODO: implement your geometry logic */

    /* Commit — use EDERR_USERABORT to cancel without applying */
    op->done( op->state, EDERR_NONE, 0 );

    return AFUNC_OK;
}

/* ---- Server record --------------------------------------------- */
ServerRecord ServerDesc[] = {
    { LWMESHEDIT_CLASS, "PLUGIN_NAME", Activate },
    { NULL }
};
