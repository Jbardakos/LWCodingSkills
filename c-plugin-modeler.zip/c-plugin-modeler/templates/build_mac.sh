#!/bin/bash
# build_mac.sh — macOS build script for LightWave .p plugin
# TODO: set PLUGIN_NAME and SOURCE below

PLUGIN_NAME="PLUGIN_NAME"
SOURCE="${PLUGIN_NAME}.c"
OUTPUT="${PLUGIN_NAME}.p"

# Real 2024.2 SDK include dir (verify: ls "$SDK"/lwserver.h).
# NOTE: older notes say /Users/mac/Applications/Lightwave3d_2024.2.0/sdk/include
# — that path does NOT exist on a normal install. The headers ship inside the
# app bundle under sdk/lwsdk<version>/include.
SDK="/Applications/LightWaveDigital/LightWave3D_2024.2.0/sdk/lwsdk2024.2/include"

# Build universal binary (Apple Silicon + Intel).
#  -D_MACOS is REQUIRED. lwserver.h only defines XCALL_(t) under _MSWIN / _LINUX
#  / _MACOS, and clang predefines none of those. Without it the XCALL_(int) in
#  front of Activate() never expands -> "expected function body after function
#  declarator". (Same applies to any host entry point.)
clang -dynamiclib \
      -D_MACOS \
      -I"$SDK" \
      -o "$OUTPUT" \
      "$SOURCE" \
      -lm \
      -framework CoreFoundation \
      -arch arm64 -arch x86_64

if [ $? -eq 0 ]; then
    echo "✓ Built: $OUTPUT"
    echo ""
    echo "If Gatekeeper quarantine blocks the file, run:"
    echo "  xattr -d com.apple.quarantine $OUTPUT"
else
    echo "✗ Build failed."
    exit 1
fi
