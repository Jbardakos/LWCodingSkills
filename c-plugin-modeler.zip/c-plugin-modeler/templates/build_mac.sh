#!/bin/bash
# build_mac.sh — macOS build script for LightWave .p plugin
# TODO: set PLUGIN_NAME and SOURCE below

PLUGIN_NAME="PLUGIN_NAME"
SOURCE="${PLUGIN_NAME}.c"
OUTPUT="${PLUGIN_NAME}.p"

SDK="/Users/mac/Applications/Lightwave3d_2024.2.0/sdk/include"

# Build universal binary (Apple Silicon + Intel)
clang -dynamiclib \
      -I"$SDK" \
      -o "$OUTPUT" \
      "$SOURCE" \
      -lm \
      -framework CoreFoundation \
      -arch arm64 -arch x86_64

if [ $? -eq 0 ]; then
    echo "✓ Built: $OUTPUT"
    echo ""
    echo "If Gatekeeper quarantine blocks the file, run:"
    echo "  xattr -d com.apple.quarantine $OUTPUT"
else
    echo "✗ Build failed."
    exit 1
fi
