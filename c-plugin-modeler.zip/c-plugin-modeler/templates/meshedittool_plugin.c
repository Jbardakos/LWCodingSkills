/*
 * meshedittool_plugin.c — TEMPLATE: interactive Modeler tool with live,
 * draggable viewport handles (LWMESHEDITTOOL_CLASS).
 * -----------------------------------------------------------------------
 * Behaviour of this template: click-drag to drop handle A and B, keep both
 * live & draggable from ANY viewport, then bake an axis-aligned box spanning
 * A..B (subdivided into `Segments` layers) when "Make Box" is pressed.
 *
 * Replace PLUGIN_NAME, and replace the body of Build() with your geometry.
 * The handle / panel / commit machinery around it stays the same.
 *
 * Build (macOS):  see templates/build_mac.sh  (REMEMBER -D_MACOS)
 *
 * Header note: the interactive class is declared in lwmodtool.h + lwtool.h;
 * MeshEditOp is in lwmeshedt.h. Reconcile #includes against your real SDK if
 * names differ:  grep -rn "MESHEDITTOOL\|LWToolFuncs" "$SDK"
 */

#include <lwserver.h>
#include <lwmeshedt.h>     /* MeshEditOp: addPoint/addFace/...                */
#include <lwtool.h>        /* LWToolFuncs, LWToolEvent, LWWireDrawAccess, LWT_* */
#include <lwmodtool.h>     /* LWMeshEditTool, LWMESHEDITTOOL_CLASS/_VERSION   */
#include <lwxpanel.h>      /* numeric panel                                   */

#include <math.h>
#include <stdlib.h>

/* XPanels reserves value IDs below 0x8000. */
#define ID_SEGS   0x8001
#define ID_APPLY  0x8002

#define SURFACE_NAME "Tool"
#define MAXR  1.0e12

typedef struct st_ToolData {
    double a[3], b[3];     /* the two handle positions (model space)  */
    int    segs;           /* panel value: box subdivisions in Y      */
    int    active;         /* has the user started?                   */
    int    drag;           /* which handle is being dragged: 0/1, -1  */
    int    dirty;          /* needs redraw?                           */
    int    update;         /* LWT_TEST_* returned by Test()           */
} ToolData;

static LWXPanelFuncs *xpanf = NULL;

/* ---- vector helpers --------------------------------------------- */
static void   v_copy(const double *u, double *o){ o[0]=u[0];o[1]=u[1];o[2]=u[2]; }
static void   v_sub (const double *u,const double *v,double *o){ o[0]=u[0]-v[0];o[1]=u[1]-v[1];o[2]=u[2]-v[2]; }
static double v_dot (const double *u,const double *v){ return (u[0]*v[0]+u[1]*v[1])+u[2]*v[2]; }
static double v_len (const double *u){ return sqrt(v_dot(u,u)); }
static void   v_norm(double *u){ double l=v_len(u); if(l>1e-12){u[0]/=l;u[1]/=l;u[2]/=l;} }

/* Safe unit copy of the viewport depth axis (LWToolEvent.axis). */
static void safe_axis(const double *a, double *o){
    v_copy(a,o);
    if (v_len(o)<1e-9){ o[0]=0;o[1]=0;o[2]=1; } else v_norm(o);
}
/* Handle-vs-cursor distance AS SEEN in this view (depth removed), so a handle
   can be grabbed from any viewport even if it is off the construction plane. */
static double pick_dist(const double *p,const double *q,const double *axis){
    double d[3],s; v_sub(p,q,d); s=v_dot(d,axis);
    d[0]-=s*axis[0]; d[1]-=s*axis[1]; d[2]-=s*axis[2];
    return v_len(d);
}
/* Move a point to the cursor IN THE VIEW PLANE while keeping its existing
   depth along the view axis. Absolute (no accumulated deltaSnap) -> consistent
   across viewports and immune to window resize. See SKILL.md gotchas 1, 2. */
static void to_cursor(double *p,const double *cursor,const double *axis){
    double dn=v_dot(p,axis), dc=v_dot(cursor,axis), s=dn-dc;
    p[0]=cursor[0]+s*axis[0]; p[1]=cursor[1]+s*axis[1]; p[2]=cursor[2]+s*axis[2];
}

/* ================================================================= */
/* Geometry — LIVE PREVIEW. Never call op->done() here; commit/reject */
/* is driven by Test()'s return code. Replace this with your shape.   */
/* ================================================================= */
static LWError Build(void *inst, MeshEditOp *op)
{
    ToolData *t = (ToolData *)inst;
    int   n = (t->segs < 1) ? 1 : t->segs, j, c;
    double lo[3], hi[3];
    LWPntID *pts;

    if (!t->active) return NULL;
    for (j=0;j<3;j++){ lo[j]=(t->a[j]<t->b[j])?t->a[j]:t->b[j];
                       hi[j]=(t->a[j]>t->b[j])?t->a[j]:t->b[j]; }
    if ((hi[0]-lo[0])+(hi[1]-lo[1])+(hi[2]-lo[2]) < 1e-9) return NULL;

    /* (n+1) layers in Y, 4 corners each: (lo.x,lo.z)(hi.x,lo.z)(hi.x,hi.z)(lo.x,hi.z) */
    pts = (LWPntID*)malloc(sizeof(LWPntID)*(size_t)(n+1)*4);
    if (!pts) return "tool: out of memory";
    for (j=0;j<=n;j++){
        double y = lo[1] + (hi[1]-lo[1])*((double)j/(double)n);
        double cx[4]={lo[0],hi[0],hi[0],lo[0]}, cz[4]={lo[2],lo[2],hi[2],hi[2]};
        for (c=0;c<4;c++){ double p[3]={cx[c],y,cz[c]}; pts[j*4+c]=op->addPoint(op->state,p); }
    }
    for (j=0;j<n;j++)                                  /* 4 side walls */
        for (c=0;c<4;c++){
            int cn=(c+1)&3; LWPntID q[4];
            q[0]=pts[j*4+c]; q[1]=pts[j*4+cn]; q[2]=pts[(j+1)*4+cn]; q[3]=pts[(j+1)*4+c];
            op->addFace(op->state, SURFACE_NAME, 4, q);
        }
    {   LWPntID bot[4], top[4];                         /* end caps */
        for (c=0;c<4;c++){ bot[c]=pts[(3-c)]; top[c]=pts[n*4+c]; }
        op->addFace(op->state, SURFACE_NAME, 4, bot);
        op->addFace(op->state, SURFACE_NAME, 4, top);
    }
    free(pts);
    t->update = LWT_TEST_NOTHING;
    return NULL;
}

/* ================================================================= */
/* Tool callbacks. count()==0 -> we do our own raw picking & drawing. */
/* ================================================================= */
static int Count(void *inst, LWToolEvent *e){ (void)inst;(void)e; return 0; }

static int Down(void *inst, LWToolEvent *e)
{
    ToolData *t = (ToolData *)inst;
    double vax[3]; safe_axis(e->axis, vax);

    if (!t->active){                              /* first click: drop A=B */
        v_copy(e->posSnap, t->a); v_copy(e->posSnap, t->b);
        t->active = 1; t->drag = 1;               /* drag B */
    } else {                                      /* grab nearest handle */
        double da = pick_dist(e->posRaw, t->a, vax);
        double db = pick_dist(e->posRaw, t->b, vax);
        t->drag = (da <= db) ? 0 : 1;
    }
    t->dirty = 1; t->update = LWT_TEST_UPDATE;
    return 1;
}
static void Move(void *inst, LWToolEvent *e)
{
    ToolData *t = (ToolData *)inst;
    double vax[3]; safe_axis(e->axis, vax);
    if (t->drag == 0) to_cursor(t->a, e->posSnap, vax);
    else if (t->drag == 1) to_cursor(t->b, e->posSnap, vax);
    else return;
    t->dirty = 1; t->update = LWT_TEST_UPDATE;
}
static void Up(void *inst, LWToolEvent *e){ ToolData *t=(ToolData*)inst;(void)e; t->drag=-1; }

static int Dirty(void *inst){
    ToolData *t=(ToolData*)inst;
    return t->dirty ? (LWT_DIRTY_WIREFRAME|LWT_DIRTY_HELPTEXT) : 0;
}
static int Test(void *inst){ return ((ToolData*)inst)->update; }

static void Draw(void *inst, LWWireDrawAccess *d)
{
    ToolData *t = (ToolData *)inst;
    double rad = (d->pxScale>0.0) ? d->pxScale*4.0 : 0.0;
    LWFVector f;
    if (!t->active) return;
    f[0]=(float)t->a[0];f[1]=(float)t->a[1];f[2]=(float)t->a[2];
    d->moveTo(d->data,f,LWWIRE_SOLID); if(rad>0)d->circle(d->data,rad,0);
    d->moveTo(d->data,f,LWWIRE_SOLID);
    f[0]=(float)t->b[0];f[1]=(float)t->b[1];f[2]=(float)t->b[2];
    d->lineTo(d->data,f,LWWIRE_ABSOLUTE);
    d->moveTo(d->data,f,LWWIRE_SOLID); if(rad>0)d->circle(d->data,rad,0);
    t->dirty = 0;                                  /* canonical: clear in draw */
}
static const char *Help(void *inst, LWToolEvent *e){
    (void)inst;(void)e;
    return "Tool: click-drag A->B, grab either handle in any view, Make Box to bake.";
}
static void Event(void *inst, int code)
{
    ToolData *t = (ToolData *)inst;
    switch (code){
        case LWT_EVENT_DROP:  if (t->active) t->update = LWT_TEST_REJECT; break;
        case LWT_EVENT_RESET: t->active=0; t->drag=-1; t->segs=1;
                              t->dirty=1; t->update=LWT_TEST_REJECT; break;
        case LWT_EVENT_ACTIVATE: t->dirty = 1; break;
    }
}
static void End(void *inst, int keep){
    ToolData *t=(ToolData*)inst;(void)keep;
    t->update=LWT_TEST_NOTHING; t->active=0; t->drag=-1;
}
static void Done(void *inst){ free(inst); }

/* ================================================================= */
/* Numeric panel (LWXP_VIEW): a value + a "Make Box" button.          */
/* ================================================================= */
static void *PanelGet(void *inst, unsigned int vid){
    ToolData *t=(ToolData*)inst;
    return (vid==ID_SEGS) ? (void*)&t->segs : NULL;
}
static LWXPRefreshCode PanelSet(void *inst, unsigned int vid, void *value){
    ToolData *t=(ToolData*)inst;
    if (vid!=ID_SEGS) return LWXPRC_NONE;
    t->segs = *(int*)value; if (t->segs<1) t->segs=1;
    t->dirty=1; t->update=LWT_TEST_UPDATE;
    return LWXPRC_DRAW;
}
/* The explicit apply: make Test() return ACCEPT so the preview is baked. */
static void OnMake(LWXPanelID pan, int cid){
    ToolData *t; (void)cid;
    if (!xpanf) return;
    t = (ToolData*)xpanf->getData(pan,0);
    if (!t) return;
    t->update = LWT_TEST_ACCEPT; t->dirty = 1;
}
static LWXPanelID Panel(void *inst)
{
    ToolData *t = (ToolData *)inst;
    LWXPanelID pan;
    static LWXPanelControl  ctl[]  = { {ID_SEGS,"Segments","integer"},
                                       {ID_APPLY,"Make Box","vButton"}, {0} };
    static LWXPanelDataDesc cdata[] = { {ID_SEGS,"Segments","integer"}, {0} };
    LWXPanelHint hint[] = { XpLABEL(0,"Tool"), XpMIN(ID_SEGS,1),
                            XpBUTNOTIFY(ID_APPLY, OnMake), XpEND };
    if (!xpanf) return NULL;
    pan = xpanf->create(LWXP_VIEW, ctl);
    if (!pan) return NULL;
    xpanf->describe(pan, cdata, PanelGet, PanelSet);
    xpanf->hint(pan, 0, hint);
    xpanf->viewInst(pan, t);
    xpanf->setData(pan, 0, t);          /* so OnMake can fetch the instance */
    return pan;
}

/* ================================================================= */
/* Activation. 3rd param is void* in ActivateFunc — cast it.          */
/* ================================================================= */
static LWToolFuncs toolFuncs;            /* zero-initialised */

XCALL_(int)
Activate(int version, GlobalFunc *global, void *localData, void *serverData)
{
    LWMeshEditTool *local = (LWMeshEditTool *)localData;
    ToolData *t;
    (void)serverData;

    if (version != LWMESHEDITTOOL_VERSION) return AFUNC_BADVERSION;

    xpanf = (LWXPanelFuncs *)global(LWXPANELFUNCS_GLOBAL, GFUSE_TRANSIENT);

    t = (ToolData *)calloc(1, sizeof(ToolData));
    if (!t) return AFUNC_OK;
    t->segs = 1; t->drag = -1; t->update = LWT_TEST_NOTHING;

    toolFuncs.done   = Done;
    toolFuncs.draw   = Draw;
    toolFuncs.help   = Help;
    toolFuncs.dirty  = Dirty;
    toolFuncs.count  = Count;
    toolFuncs.down   = Down;
    toolFuncs.move   = Move;
    toolFuncs.up     = Up;
    toolFuncs.event  = Event;
    toolFuncs.panel  = Panel;

    local->instance = t;
    local->tool     = &toolFuncs;
    local->test     = Test;
    local->build    = Build;
    local->end      = End;
    return AFUNC_OK;
}

ServerRecord ServerDesc[] = {
    { LWMESHEDITTOOL_CLASS, "PLUGIN_NAME", Activate },
    { NULL }
};
