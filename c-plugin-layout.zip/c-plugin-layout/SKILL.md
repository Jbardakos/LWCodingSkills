---
name: c-plugin-layout
description: >
  Use this skill for compiled C/C++ handler plugins (.p files) targeting LightWave
  Layout. Covers the full handler pattern: instance callbacks (create/destroy/copy/
  load/save/descln), item dependency (useItems/changeID), render callbacks
  (init/cleanup/newTime), class-specific evaluate/flags, and XPanels UI. Covers
  Displacement, ItemMotion, MeshDeformer, Shader, Environment, and other handler
  classes. Trigger when a user asks to write, build, or debug a compiled Layout
  plugin in C or C++.
---

# C / C++ Plugin — LightWave Layout Handlers

## ⚠️ STEP 0: READ THE TEMPLATE FIRST ⚠️

Read `templates/layout_handler.c` and use it as the **literal starting point**.
Replace `PLUGIN_NAME`. Swap the class header, handler struct, version constant,
and class string. Fill in `TODO` sections. Do not write from scratch.

The template is pre-wired for `LWDisplacementHandler` as a concrete example.
Adapt the marked lines for other handler classes.

---

## Handler Class Quick Reference

| Class | Header | Handler struct | Version constant | Class string |
|-------|--------|---------------|-----------------|-------------|
| Displacement | `lwdisplce.h` | `LWDisplacementHandler` | `LWDISPLACEMENT_VERSION` | `LWDISPLACEMENT_CLASS` |
| Item Motion | `lwitmmot.h` | `LWItemMotionHandler` | `LWITEMMOTION_VERSION` | `LWITEMMOTION_CLASS` |
| Mesh Deformer | `lwmeshmod.h` | `LWMeshDeformerHandler` | `LWMESHDEFORMER_VERSION` | `LWMESHDEFORMER_CLASS` |
| Shader (classic) | `lwshader.h` | `LWShaderHandler` | `LWSHADER_VERSION` | `LWSHADER_CLASS` |
| Surface Shader | `lwsurfaceshader.h` | `LWSurfaceShaderHandler` | `LWSURFACESHADER_VERSION` | `LWSURFACESHADER_CLASS` |
| Environment | `lwenviron.h` | `LWEnvironmentHandler` | `LWENVIRONMENT_VERSION` | `LWENVIRONMENT_CLASS` |
| Image Filter | `lwimgflt.h` | `LWImageFilterHandler` | `LWIMAGEFILTER_VERSION` | `LWIMAGEFILTER_CLASS` |
| Pixel Filter | `lwpixflt.h` | `LWPixelFilterHandler` | `LWPIXELFILTER_VERSION` | `LWPIXELFILTER_CLASS` |
| Master | `lwmaster.h` | `LWMasterHandler` | `LWMASTER_VERSION` | `LWMASTER_CLASS` |
| Custom Object | `lwcustobj.h` | `LWCustomObjHandler` | `LWCUSTOMOBJ_VERSION` | `LWCUSTOMOBJ_CLASS` |

---

## Full Handler Activation Pattern

Every handler activation function follows this pattern:

```c
XCALL_( int )
Activate( int version, GlobalFunc *global,
          LWXxxHandler *local, void *serverData )
{
    if ( version != LWXXX_VERSION ) return AFUNC_BADVERSION;

    local->inst->create  = Create;    /* required */
    local->inst->destroy = Destroy;   /* required */
    local->inst->copy    = Copy;
    local->inst->load    = Load;
    local->inst->save    = Save;
    local->inst->descln  = Descln;

    if ( local->item ) {
        local->item->useItems = UseItems;
        local->item->changeID = ChangeID;
    }
    if ( local->rend ) {
        local->rend->init    = Init;
        local->rend->cleanup = Cleanup;
        local->rend->newTime = NewTime;
    }

    local->evaluate = Evaluate;
    local->flags    = Flags;
    return AFUNC_OK;
}
```

---

## Instance Callbacks

```c
/* Called when plugin is applied or scene loaded */
LWInstance Create( void *priv, void *context, LWError *err );

/* Called when plugin is removed or scene cleared */
void Destroy( LWInstance inst );

/* Copy settings from one instance to another */
LWError Copy( LWInstance to, LWInstance from );

/* Read settings from scene file */
LWError Load( LWInstance inst, const LWLoadState *ls );

/* Write settings to scene file */
LWError Save( LWInstance inst, const LWSaveState *ss );

/* Return short description string for Layout panel */
const char * Descln( LWInstance inst );
```

All return `NULL` (not `0`) to indicate success.

---

## Load / Save Macros

```c
/* Floating point (double) */
LWLOAD_FP ( ls, &val, count );
LWSAVE_FP ( ss, &val, count );

/* Integer */
LWLOAD_I4 ( ls, &val, count );
LWSAVE_I4 ( ss, &val, count );

/* String (fixed buffer) */
LWLOAD_STR( ls, buf, sizeof(buf) );
LWSAVE_STR( ss, buf );
```

Always read in the **same order** as written.

---

## Item Dependency Callbacks

Declare which scene items your plugin reads. Layout uses this to control
evaluation order so your plugin always sees up-to-date transforms.

```c
static const LWItemID *
UseItems( LWInstance inst )
{
    static LWItemID ids[2];
    ids[0] = myData->watchedItem;
    ids[1] = LWITEM_NULL;              /* sentinel */
    return ids;
    /* Return NULL if no dependencies */
    /* Return LWITEM_ALL to re-evaluate after any change */
}

static void
ChangeID( LWInstance inst, const LWItemID *pairs )
{
    /* pairs[] is old/new alternating, terminated by LWITEM_NULL */
    int i;
    for ( i = 0; pairs[i] != LWITEM_NULL; i += 2 )
        if ( myData->item == pairs[i] )
            myData->item = pairs[i+1];
}
```

---

## Displacement Access Structure

```c
typedef struct st_LWDisplacementAccess {
    LWDVector    oPos;    /* original position, READ-ONLY */
    LWDVector    source;  /* position to modify IN PLACE  */
    LWPntID      point;
    LWMeshInfo  *info;
    LWDVector    wNorm;   /* valid only if LWDMF_NEED_NORMALS returned */
} LWDisplacementAccess;
```

Displacement flags: `LWDMF_WORLD`, `LWDMF_BEFOREBONES`,
`LWDMF_AFTERMORPH`, `LWDMF_LAST`, `LWDMF_NEED_NORMALS`

---

## Classic Shader Access Structure

```c
typedef struct st_LWShaderAccess {
    /* Geometry */
    LWDVector    oPos, wPos;          /* object/world position */
    LWDVector    gNorm;               /* geometric normal      */
    LWDVector    wNorm;               /* shading normal        */
    /* Surface params (read/write) */
    double       color[3];            /* RGB, 0-1              */
    double       luminosity;
    double       diffuse;
    double       specular;
    double       mirror;
    double       transparency;
    double       eta;                 /* refraction index      */
    double       roughness;
    /* Render state */
    int          bounce;              /* recursion depth        */
    /* Raytracing (may be NULL — always check before calling!) */
    LWRayTraceFunc   *rayTrace;
    LWIlluminateFunc *illuminate;
    LWRayCastFunc    *rayCast;
    LWRayShadeFunc   *rayShade;
    /* ... many more fields in lwshader.h */
} LWShaderAccess;
```

Shader flags: `LWSHF_COLOR`, `LWSHF_LUMINOSITY`, `LWSHF_DIFFUSE`,
`LWSHF_SPECULAR`, `LWSHF_MIRROR`, `LWSHF_TRANSPARENCY`

---

## ServerDesc — Handler + Interface

Every handler needs a paired interface entry in the same ServerDesc:

```c
ServerRecord ServerDesc[] = {
    { LWDISPLACEMENT_CLASS, "MyPlugin",           PluginActivate   },
    { LWDISPLACEMENT_CLASS, "MyPlugin_Interface", InterfaceActivate },
    { NULL }
};
```

The interface activation fills in `local->panel` using XPanels.

---

## File I/O Globals

```c
#include <lwio.h>
const LWLoadState *ls;   /* read handle */
const LWSaveState *ss;   /* write handle */

LWLOAD_FP( ls, &myDouble, 1 );
LWSAVE_FP( ss, &myDouble, 1 );
LWLOAD_I4( ls, &myInt,    1 );
LWSAVE_I4( ss, &myInt,    1 );
LWLOAD_STR( ls, buf, sizeof(buf) );
LWSAVE_STR( ss, buf );
```

---

## macOS Build

```bash
SDK="/Users/mac/Applications/Lightwave3d_2024.2.0/sdk/include"
clang -dynamiclib -I"$SDK" -o PLUGIN_NAME.p PLUGIN_NAME.c \
      -lm -framework CoreFoundation -arch arm64 -arch x86_64
xattr -d com.apple.quarantine PLUGIN_NAME.p
```

---

## Gotchas

1. **Version check is mandatory** — `AFUNC_BADVERSION` first, always.
2. **`local->item` and `local->rend` may be NULL** for some classes — always guard with `if`.
3. **`UseItems` must be accurate** — missing dependencies causes stale data at render time.
4. **`ChangeID` must update all stored `LWItemID`s** — forgetting causes dangling IDs.
5. **Shader raytracing functions may be NULL** (e.g. during preview) — check before calling.
6. **`Descln` returns a static buffer** — not thread-safe for multi-instance; use a per-instance buffer.
7. **Load/Save order must match exactly** — mismatches corrupt scene data silently.
8. **Universal Binary**: always `-arch arm64 -arch x86_64` on macOS.
