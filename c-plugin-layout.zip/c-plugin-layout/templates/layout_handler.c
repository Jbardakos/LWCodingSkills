/*
 * PLUGIN_NAME — LightWave Layout Handler Plugin (C/C++)
 * TODO: Replace PLUGIN_NAME throughout this file
 *
 * TEMPLATE: Layout Handler
 * This file shows the full handler pattern:
 *   - instance callbacks (create, destroy, copy, load, save, descln)
 *   - item callbacks     (useItems, changeID)
 *   - render callbacks   (init, cleanup, newTime)
 *   - class-specific evaluate / flags
 *
 * Adapt for the class you need by including the appropriate header
 * and changing the class constants and local struct type.
 * Common choices:
 *   Displacement : lwdisplce.h   / LWDisplacementHandler / LWDISPLACEMENT_CLASS
 *   ItemMotion   : lwitmmot.h    / LWItemMotionHandler   / LWITEMMOTION_CLASS
 *   MeshDeformer : lwmeshmod.h   / LWMeshDeformerHandler / LWMESHDEFORMER_CLASS
 *   Shader       : lwshader.h    / LWShaderHandler       / LWSHADER_CLASS
 *   Environment  : lwenviron.h   / LWEnvironmentHandler  / LWENVIRONMENT_CLASS
 */

#include <lwserver.h>
#include <lwhandler.h>    /* LWInstanceFuncs, LWItemFuncs, LWRenderFuncs */
#include <lwdisplce.h>    /* TODO: swap for your target class header     */
#include <lwxpanel.h>
#include <lwmessage.h>
#include <lwtxtr.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* ------------------------------------------------------------------ */
/* Instance data — one block allocated per plugin application          */
/* ------------------------------------------------------------------ */
typedef struct {
    /* TODO: add your parameters here, e.g.: */
    double  amplitude;
    double  frequency;
    LWItemID targetItem;
} MyData;

/* ------------------------------------------------------------------ */
/* Instance callbacks                                                   */
/* ------------------------------------------------------------------ */

static LWInstance
Create( void *priv, void *context, LWError *err )
{
    MyData *dat = (MyData *)calloc( 1, sizeof(MyData) );
    if ( !dat ) { *err = "Out of memory"; return NULL; }

    /* TODO: set defaults */
    dat->amplitude = 0.1;
    dat->frequency = 1.0;
    dat->targetItem = LWITEM_NULL;

    return (LWInstance)dat;
}

static void
Destroy( LWInstance inst )
{
    if ( inst ) free( inst );
}

static LWError
Copy( LWInstance to, LWInstance from )
{
    *(MyData *)to = *(MyData *)from;
    return NULL;   /* NULL = success */
}

static LWError
Load( LWInstance inst, const LWLoadState *ls )
{
    MyData *dat = (MyData *)inst;
    /* TODO: read in same order as Save, e.g.: */
    /* LWLOAD_FP( ls, &dat->amplitude, 1 ); */
    /* LWLOAD_FP( ls, &dat->frequency, 1 ); */
    return NULL;
}

static LWError
Save( LWInstance inst, const LWSaveState *ss )
{
    MyData *dat = (MyData *)inst;
    /* TODO: write in same order as Load, e.g.: */
    /* LWSAVE_FP( ss, &dat->amplitude, 1 ); */
    /* LWSAVE_FP( ss, &dat->frequency, 1 ); */
    return NULL;
}

static const char *
Descln( LWInstance inst )
{
    static char buf[128];
    MyData *dat = (MyData *)inst;
    /* TODO: format a short description for the Layout panel */
    sprintf( buf, "PLUGIN_NAME A=%.3f F=%.2f", dat->amplitude, dat->frequency );
    return buf;
}

/* ------------------------------------------------------------------ */
/* Item callbacks (dependency tracking)                                 */
/* ------------------------------------------------------------------ */

static const LWItemID *
UseItems( LWInstance inst )
{
    static LWItemID items[2];
    MyData *dat = (MyData *)inst;
    items[0] = dat->targetItem;    /* NULL = LWITEM_NULL = end of list */
    items[1] = LWITEM_NULL;
    return ( dat->targetItem != LWITEM_NULL ) ? items : NULL;
}

static void
ChangeID( LWInstance inst, const LWItemID *ids )
{
    MyData *dat = (MyData *)inst;
    int i;
    for ( i = 0; ids[i] != LWITEM_NULL; i += 2 ) {
        if ( dat->targetItem == ids[i] )
            dat->targetItem = ids[i+1];
    }
}

/* ------------------------------------------------------------------ */
/* Render callbacks                                                     */
/* ------------------------------------------------------------------ */

static LWError
Init( LWInstance inst, int mode )
{
    /* mode = LWINIT_PREVIEW or LWINIT_RENDER */
    /* TODO: pre-render setup */
    return NULL;
}

static void
Cleanup( LWInstance inst )
{
    /* TODO: post-render cleanup */
}

static LWError
NewTime( LWInstance inst, LWFrame frame, LWTime time )
{
    /* Called at the start of each sampling pass */
    /* TODO: per-frame cache updates */
    return NULL;
}

/* ------------------------------------------------------------------ */
/* Class-specific evaluate — DISPLACEMENT example                       */
/* TODO: replace with your class's evaluate signature                   */
/* ------------------------------------------------------------------ */

static void
Evaluate( LWInstance inst, LWDisplacementAccess *da )
{
    MyData *dat = (MyData *)inst;
    /*
     * da->oPos[3]    — original position, read-only
     * da->source[3]  — position to displace IN PLACE
     * da->point      — LWPntID
     * da->info       — LWMeshInfo*
     *
     * TODO: compute displacement, e.g.:
     */
    double x = da->source[0];
    da->source[1] += dat->amplitude *
                     sin( dat->frequency * x * 6.2831853 );
}

static unsigned int
Flags( LWInstance inst )
{
    /* TODO: choose coordinate space:
     *   LWDMF_WORLD       — world space (after object motion)
     *   LWDMF_BEFOREBONES — before bone deformation
     *   LWDMF_AFTERMORPH  — after morph targets
     *   LWDMF_LAST        — after all deformations including subdivision
     */
    return LWDMF_WORLD;
}

/* ------------------------------------------------------------------ */
/* Interface activation (XPanels)                                       */
/* ------------------------------------------------------------------ */

#define CTRL_AMP  1
#define CTRL_FREQ 2

static LWXPanelHint panelHints[] = {
    XpLABEL( 0,        "PLUGIN_NAME" ),
    XpF64  ( CTRL_AMP, "Amplitude" ),
    XpF64  ( CTRL_FREQ, "Frequency" ),
    XpEND
};

XCALL_( static int )
Interface( int version, GlobalFunc *global,
           LWInterface *local, void *serverData )
{
    LWXPanelFuncs *xpanf = global( LWXPANELFUNCS_GLOBAL, GFUSE_TRANSIENT );
    MyData        *dat   = (MyData *)local->inst;

    if ( !xpanf ) return AFUNC_BADGLOBAL;

    local->panel   = xpanf->create( LWXP_VIEW, panelHints );
    local->options = NULL;
    local->command = NULL;

    if ( local->panel ) {
        xpanf->formSet( local->panel, CTRL_AMP,  &dat->amplitude );
        xpanf->formSet( local->panel, CTRL_FREQ, &dat->frequency );
    }
    return AFUNC_OK;
}

/* ------------------------------------------------------------------ */
/* Activation function                                                  */
/* TODO: change LWDisplacementHandler to your target handler struct     */
/* TODO: change LWDISPLACEMENT_VERSION accordingly                      */
/* ------------------------------------------------------------------ */

XCALL_( int )
Activate( int version, GlobalFunc *global,
          LWDisplacementHandler *local, void *serverData )
{
    if ( version != LWDISPLACEMENT_VERSION )
        return AFUNC_BADVERSION;

    /* Instance */
    local->inst->priv    = NULL;
    local->inst->create  = Create;
    local->inst->destroy = Destroy;
    local->inst->copy    = Copy;
    local->inst->load    = Load;
    local->inst->save    = Save;
    local->inst->descln  = Descln;

    /* Item */
    if ( local->item ) {
        local->item->useItems = UseItems;
        local->item->changeID = ChangeID;
    }

    /* Render */
    if ( local->rend ) {
        local->rend->init    = Init;
        local->rend->cleanup = Cleanup;
        local->rend->newTime = NewTime;
    }

    /* Class-specific */
    local->evaluate = Evaluate;
    local->flags    = Flags;

    return AFUNC_OK;
}

/* ------------------------------------------------------------------ */
/* Server record                                                         */
/* TODO: change class string and "PLUGIN_NAME" to your plugin name      */
/* ------------------------------------------------------------------ */
ServerRecord ServerDesc[] = {
    { LWDISPLACEMENT_CLASS, "PLUGIN_NAME",           Activate  },
    { LWDISPLACEMENT_CLASS, "PLUGIN_NAME_Interface", Interface },
    { NULL }
};
