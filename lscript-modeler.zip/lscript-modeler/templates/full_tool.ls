// ============================================================
// ScriptName:    PLUGIN_NAME
// ScriptID:      studio.PLUGIN_NAME
// ScriptVersion: 1.0.0
// TargetApp:     modeler
// LightWaveVersion: unspecified
// Dependencies:  none
// Author:        Dr. Iannis Bardakos
// License:       proprietary
// TestedOn:      macOS / LightWave 2024
// ============================================================
//
// TODO: Replace PLUGIN_NAME above and throughout.
// TEMPLATE: Full Production Tool
// Use this when your script needs:
//   - user input (requester)
//   - selection validation
//   - undo grouping
//   - progress monitor with cancel
//   - both CS and MD operations
// ============================================================

@version 2.3
@warnings
@script modeler
@name *PLUGIN_NAME          // asterisk = visible in menu searches

main
{
    // ---- 1. UI — gather user input -------------------------
    reqbegin("PLUGIN_NAME");

        // TODO: add controls, e.g.:
        // c1 = ctlnumber("Scale", 1.0);
        // c2 = ctlinteger("Segments", 4);
        // c3 = ctlvector("Offset", <0,0,0>);

    return if !reqpost();

        // TODO: read values, e.g.:
        // scl  = getvalue(c1);
        // segs = getvalue(c2);
        // off  = getvalue(c3);

    reqend();

    // ---- 2. Precondition checks ----------------------------
    // Validate selection BEFORE entering edit mode.
    selmode(USER);                       // respect user selection
    pCnt  = pointcount();
    pyCnt = polycount();

    // TODO: choose appropriate validation, e.g.:
    if(pyCnt < 1)
        error("Select one or more polygons.");
    // if(pCnt < 1) error("Select one or more points.");

    // ---- 3. CS pre-work (optional) -------------------------
    // CS commands can run here freely.
    // TODO: layer setup, boolean ops, primitive creation if needed, e.g.:
    // lyrfg(1);         // set foreground to layer 1
    // lyrswap();        // swap fg/bg for boolean operations

    // ---- 4. Undo group + MD edit ---------------------------
    undogroupbegin();

        // Monitor: pass total step count
        moninit(pyCnt);

        editbegin();

            for(i = 1; i <= pyCnt; i++)
            {
                poly = polygons[i];

                // TODO: per-polygon work, e.g.:
                // norm = polynormal(poly);
                // polysurface(poly, "NewSurface");

                // Check if user pressed Cancel
                if(monstep())
                {
                    editend(false);       // discard changes
                    monend();
                    undogroupend();
                    return;
                }
            }

        editend();
        monend();

    undogroupend();

    // ---- 5. CS post-work (optional) ------------------------
    // TODO: mergepoints, triple, smooth, etc.
}
