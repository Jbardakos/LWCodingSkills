@version 2.3
@warnings
@script modeler
@name PLUGIN_NAME

// ============================================================
// TODO: Replace PLUGIN_NAME above with your script name
// TEMPLATE: Scan + Modify — iterate selected points or polygons
// Use for: offsets, per-point transforms, surface reassignment
// ============================================================

main
{
    // ---- UI ------------------------------------------------
    reqbegin("PLUGIN_NAME");

        // TODO: controls

    return if !reqpost();

        // TODO: read values

    reqend();

    // ---- Operate on user selection -------------------------
    selmode(USER);   // respect current user selection
    // Use selmode(DIRECT) to operate on ALL geometry regardless

    moninit(editbegin());

        // POINT LOOP — runs over all selected points
        foreach(p, points)
        {
            pos = pointinfo(p);   // returns <x,y,z> vector

            // TODO: modify pos, e.g.:
            // pos.y += 0.1;

            // NOTE: to write back you need pntMove from C SDK.
            // In LScript MD mode, direct position write is not
            // available — use a CS move after editend() instead,
            // or build a displacement list and apply via move().

            monstep();
        }

        // POLYGON LOOP — runs over all selected polygons
        // foreach(poly, polygons)
        // {
        //     polysurface(poly, "NewSurface");
        //     monstep();
        // }

    monend();
    editend();
}
