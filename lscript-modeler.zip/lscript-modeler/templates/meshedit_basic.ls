@version 2.3
@warnings
@script modeler
@name PLUGIN_NAME

// ============================================================
// TODO: Replace PLUGIN_NAME above with your script name
// TEMPLATE: MeshDataEdit (MD) — direct point/polygon access
// Use for: creating geometry, modifying individual points/polys
// ============================================================

main
{
    // ---- UI ------------------------------------------------
    reqbegin("PLUGIN_NAME");

        // TODO: add controls, e.g.:
        // c1 = ctlnumber("Radius", 0.5);
        // c2 = ctlinteger("Sides", 8);
        // c3 = ctlstring("Surface", "Default", 64);

    return if !reqpost();

        // TODO: read values
        // radius = getvalue(c1);
        // sides  = getvalue(c2);
        // surf   = getvalue(c3);

    reqend();

    // ---- Mesh Data Edit ------------------------------------
    // All code between editbegin() and editend() is buffered.
    // CS commands (move, rotate, etc.) are ILLEGAL here.
    // Nothing is applied until editend() is called.

    moninit(editbegin());   // enter MD mode; init progress monitor

        // TODO: create points, e.g.:
        // pt1 = addpoint(x, y, z);

        // TODO: create polygons, e.g.:
        // poly = addpolygon(@pt1, pt2, pt3@);
        // polysurface(poly, surf);

        monstep();   // advance progress monitor if looping

    monend();
    editend();   // apply all buffered changes; exit MD mode

    // ---- Optional post-edit CS commands --------------------
    // TODO: e.g. mergepoints(); triple(); smooth();
}
