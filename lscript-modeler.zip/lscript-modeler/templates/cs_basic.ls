@version 2.3
@warnings
@script modeler
@name PLUGIN_NAME

// ============================================================
// TODO: Replace PLUGIN_NAME above with your script name
// TEMPLATE: CommandSequence (CS) — no mesh data edit
// Use for: layer ops, move/rotate/scale, bevel, extrude, etc.
// ============================================================

main
{
    // ---- UI ------------------------------------------------
    reqbegin("PLUGIN_NAME");

        // TODO: add controls, e.g.:
        // c1 = ctlnumber("Scale", 1.0);
        // c2 = ctlinteger("Segments", 3);

    return if !reqpost();

        // TODO: read values, e.g.:
        // scl  = getvalue(c1);
        // segs = getvalue(c2);

    reqend();

    // ---- Work (CS mode) ------------------------------------
    // TODO: call CS commands here, e.g.:
    // move(<0, 1, 0>);
    // bevel();
    // extrude(<0, 0, 1>);
}
