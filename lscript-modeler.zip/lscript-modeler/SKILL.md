---
name: lscript-modeler
description: >
  Use this skill for any LScript code targeting LightWave Modeler. Covers script
  structure, operation modes (CS / MD), point/polygon creation, geometry traversal,
  VMap access, requester UI, layer management, undo grouping, CommandInput, and
  library system. Trigger when a user asks to write, debug, or extend an LScript
  (.ls) for Modeler tasks: mesh generation, selection operations, surface
  assignment, boolean ops, or requester interfaces.
---

# LScript — Modeler Scripting

## ⚠️ STEP 0: READ THE CORRECT TEMPLATE FIRST ⚠️

Before writing any LScript, read the appropriate template and use it as the
**literal starting point**. Replace all `PLUGIN_NAME` tokens. Fill in `TODO`.

| Task | Template to read |
|------|-----------------|
| CS commands only (move, bevel, extrude, layer ops) | `templates/cs_basic.ls` |
| Create or modify geometry at point/poly level | `templates/meshedit_basic.ls` |
| Iterate and modify selected points or polygons | `templates/scan_modify.ls` |
| Full production tool (UI + validation + undo + monitor) | `templates/full_tool.ls` |

---

## Script Header and Metadata

```lscript
// ScriptName:    Human readable tool label
// ScriptID:      studio.toolname          (stable ID for logging / settings)
// ScriptVersion: 1.0.0
// TargetApp:     modeler
// LightWaveVersion: unspecified
// Dependencies:  Common.lib
// Author:        Dr. Iannis Bardakos
// License:       proprietary
// TestedOn:      macOS / LightWave 2024

@version 2.3          // use 2.3 minimum
@warnings             // surface all warnings
@script modeler       // required
@name *MyScriptName   // asterisk = visible in menu searches
```

Entry point is always `main { }`.

**Naming convention**: `VerbNoun_Action.ls` e.g. `RestOnGround_SelectedPoints.ls`

---

## Modeler vs Layout Command Differences

Critical when porting code or issuing commands by string:

| | Modeler | Layout |
|---|---------|--------|
| Primary mechanism | `lookup` + `execute` (`evaluate` is translated) | `evaluate` strings (`lookup`/`execute` is translated) |
| Command case | **Not** case-sensitive | **Case-sensitive** |

---

## Operation Modes — The Most Important Rule

LScript Modeler commands are split into two **mutually exclusive** modes.
Calling a CS command inside MD mode (or vice versa) is a runtime error.

| Mode | Entry | Exit | Allowed commands |
|------|-------|------|-----------------|
| CS (Command Sequence) | default; after `editend()` | — | move, rotate, bevel, layer ops, primitives, booleans |
| MD (Mesh Data Edit) | `editbegin()` | `editend()` | addpoint, addpolygon, pointinfo, pointmove, polysurface |

All MD operations are **buffered** until `editend()`.
Use `editend(false)` to cancel and discard.

---

## Precondition Validation (Before editbegin)

Always validate selection **before** entering edit mode:

```lscript
selmode(USER);
pCnt  = pointcount();
pyCnt = polycount();

if(pyCnt < 1)
    error("Select one or more polygons.");
// error() stops execution immediately — use for hard failures
// warn()  shows warning but continues
// info()  informational only
```

---

## Points (MD mode)

```lscript
pt  = addpoint(x, y, z);        // create — returns LWPntID
pos = pointinfo(pt);             // query position — returns <x,y,z>
pointmove(pt, newPos);           // move existing point to absolute position
```

Automatic arrays inside MD mode:
```lscript
points[]    // IDs of selected points
polygons[]  // IDs of selected polygons
```

---

## Polygons (MD mode)

```lscript
poly = addpolygon(@pt1, pt2, pt3, pt4@);
polysurface(poly, "SurfaceName");
polytype(poly, FACE);     // FACE, CURV, PTCH, SUBD
norm = polynormal(poly);  // returns normal vector <x,y,z>
```

---

## Selection

```lscript
selmode(USER);       // use current user selection
selmode(DIRECT);     // bypass selection; access all geometry
selmode(GLOBAL);     // all layers

// Rule-based selection — require selmode(USER) first
selpoint(SET,  POSITION, <x,y,z>, radius);  // select points by rule
selpolygon(SET, AREA, minArea, maxArea);     // select polygons by rule
selinvert();                                  // invert selection
selhide(true);                               // hide selected
```

---

## Undo Grouping

Wrap multi-step operations into a single undo entry:

```lscript
undogroupbegin();
    // ... all CS and MD work here ...
undogroupend();
```

---

## Progress Monitor with Cancel Detection

```lscript
moninit(totalSteps);   // or moninit(totalSteps, "Working...");
editbegin();
    for(i = 1; i <= total; i++)
    {
        // ... work ...
        if(monstep())        // returns TRUE when user cancels
        {
            editend(false);
            monend();
            undogroupend();  // if inside an undo group
            return;
        }
    }
editend();
monend();
```

---

## Layer Operations (CS mode)

```lscript
lyrfg(1);              // set layer 1 as foreground
lyrbg(2);              // set layer 2 as background
lyrswap();             // swap fg and bg
setlayername("Name");  // name the current foreground layer
```

---

## Utility Geometry Functions

```lscript
bb = boundingbox();        // returns [minVec, maxVec]
c  = center(bb);           // centroid of bounding box
d  = dot3d(v1, v2);        // dot product — used for plane projection math
n  = polynormal(poly);     // polygon normal (MD mode)
```

---

## Primitive Creation (CS mode)

```lscript
makebox(<-0.5,-0.5,-0.5>, <0.5,0.5,0.5>, <1,1,1>);  // low, high, segs
makedisc(segments, sides, center, radius, top, bottom);
makecone();
maketext("Hello", font, alignment);
```

---

## Boolean and Drill Operations (CS mode)

Foreground = tool shape, Background = target object:

```lscript
boolean(UNION);         // or SUBTRACT, INTERSECT, ADD
axisdrill(CORE, X);     // CORE, TUNNEL, SLICE, STENCIL; axis = X, Y, Z
soliddrill(CORE);       // requires foreground/background overlap
```

---

## Common CS Commands

```lscript
move(<dx, dy, dz>);
rotate(angle, axis, center);
scale(factor, center);
bevel();
extrude(<dx, dy, dz>);
mirror(axis);
smooth();
triple();
mergepoints();             // or mergepoints(distanceTolerance)
weldpoints();              // merge to last selected point
weldaverage();
unweld();
```

---

## CommandInput and Plugin Invocation

```lscript
// Issue any Modeler command by string (case-insensitive in Modeler)
CommandInput("MAKEBOX <-0.5 -0.5 -0.5> <0.5 0.5 0.5>");

// Invoke another installed plugin by its menu label name
cmdseq("SomeInstalledPluginName");
// Unidirectional — no structured return value
```

Use `CommandInput` for commands without a dedicated LScript wrapper.
Prefer dedicated wrappers when available — they provide argument type checking.

---

## Requester UI Pattern

```lscript
reqbegin("Panel Title");
    c1 = ctlnumber("Scale", 1.0);
    c2 = ctlinteger("Segments", 4);
    c3 = ctlstring("Surface", "Default", 64);
    c4 = ctlvector("Offset", <0,0,0>);
    c5 = ctlchoice("Axis", 1, @"X","Y","Z"@);
return if !reqpost();
    s    = getvalue(c1);
    n    = getvalue(c2);
    surf = getvalue(c3);
    off  = getvalue(c4);
    ax   = getvalue(c5);
reqend();
```

Control types: `ctlnumber`, `ctlinteger`, `ctlstring`, `ctlvector`,
`ctlcheckbox`, `ctlpopup`, `ctlchoice`, `ctlslider`, `ctlminislider`,
`ctlbutton`, `ctllistbox`, `ctlsep`

Position controls: `ctlposition(handle, column, row)`

---

## VMap Access (MD mode)

```lscript
// Get the currently selected weight map (index 0 = current selection)
vmap = VMap(VMWEIGHT, 0) || error("Select a weight map first.");

// Or iterate all maps of a type
vmap = VMap(VMWEIGHT);
while(vmap && vmap.type == VMWEIGHT) {
    name = vmap.name;
    vmap = vmap.next();
}

if(vmap.isMapped(pt)) {
    values = vmap.getValue(pt);
    for(k = 1; k <= vmap.dimensions; k++)
        values[k] *= 0.5;
    vmap.setValue(pt, values);   // requires active MD session
}
```

VMap types: `VMWEIGHT`, `VMCOLOR`, `VMTEXUV`, `VMNORMAL`, `VMMORPHABS`, `VMMORPHREL`

---

## Library and Include System

```lscript
library "Common.lsc";          // compiled shared library
library "/path/to/mylib.lsc";  // explicit path

// @include "MyDefines.lsi"    // shared constants / @define macros

@define MY_CONSTANT 42
```

---

## Recommended Script Structure

```
1. Comment metadata block (ScriptName, ScriptID, Author, etc.)
2. @version, @warnings, @script, @name
3. library / @include statements
4. @define constants
5. main { }
   a. UI       — reqbegin … reqend
   b. Validate — selmode, pointcount/polycount, error if bad
   c. undogroupbegin()
   d. CS pre-work — layer setup, primitives, layer swap for booleans
   e. moninit → editbegin → loop (monstep cancel check) → editend → monend
   f. CS post-work — mergepoints, triple, smooth
   g. undogroupend()
```

---

## Gotchas

1. **Never** call CS commands inside `editbegin()` / `editend()`.
2. `editend()` **must always be called** — omitting it breaks Modeler.
3. `reqpost()` returns false on Cancel — guard: `return if !reqpost()`.
4. Array indices are **1-based**, not 0-based.
5. `points[]` / `polygons[]` only valid inside an active MD session.
6. `vmap.setValue()` requires an active MD session.
7. `selpoint()` / `selpolygon()` require `selmode(USER)` first.
8. `monstep()` returns `true` on cancel — check it and call `editend(false)`.
9. Modeler commands are **case-insensitive**; Layout commands are **case-sensitive**.
10. `pointcount()` / `polycount()` must be called **before** `editbegin()`.

---

## File Placement

| Platform | Path |
|----------|------|
| macOS | `~/Library/Application Support/LightWave3D/2024/Scripts/Modeler/` |
| Windows | `%APPDATA%\NewTek\LightWave\2024\Scripts\Modeler\` |

Run **Edit > Refresh Plugins** (`Alt+F11`) after adding scripts.
Bind scripts to menus and hotkeys via **Edit > Menu Layout**.
