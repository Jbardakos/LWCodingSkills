---
name: nodes
description: >
  Use this skill for LightWave Node Editor plugins (C/C++ NodeHandler class).
  Covers NodeHandler activation, instance callbacks, input/output creation,
  ConnectionType constants, the evaluate function pattern, LWShadingGeometry,
  NodeInputFuncs/NodeOutputFuncs, setValue/getValue, and XPanels UI.
  Trigger when a user asks to write, build, or debug a node plugin in C or C++.
---

# LightWave Node Editor — NodeHandler Plugin

## ⚠️ STEP 0: READ THE TEMPLATE FIRST ⚠️

Read `templates/node_plugin.c` and use it as the **literal starting point**.
Replace `PLUGIN_NAME`. Define your inputs, outputs, and parameters.
Implement the `Evaluate` function. Do not write from scratch.

---

## What a Node Is

A node is a plugin that appears in the LightWave Node Editor. Nodes have:
- **Inputs** — receive values from other nodes' outputs (or use defaults)
- **Outputs** — publish computed values to downstream nodes
- **Evaluate** — called per shading point during rendering

Nodes are used for surfaces, environments, motion, and any other nodal context.

---

## Headers and Class

```c
#include <lwnodes.h>           /* NodeHandler, ConnectionType, NodeValue */
#include <lwserver.h>

/* Class string and version */
#define LWNODEHANDLER_CLASS    "NodeHandler"
/* version constant: LWNODEHANDLER_VERSION */
```

---

## Activation Function

```c
XCALL_( int )
Activate( int version, GlobalFunc *global,
          LWNodeHandler *local, void *serverData )
{
    if ( version != LWNODEHANDLER_VERSION ) return AFUNC_BADVERSION;

    local->inst->create  = Create;
    local->inst->destroy = Destroy;
    local->inst->copy    = Copy;
    local->inst->load    = Load;
    local->inst->save    = Save;
    local->inst->descln  = Descln;

    local->evaluate      = Evaluate;
    local->flags         = Flags;
    local->customPreview = NULL;
    local->materialGL    = NULL;

    return AFUNC_OK;
}
```

---

## Globals Required

```c
/* Obtain in Create() or globally at activation time */
NodeInputFuncs  *inFuncs  = global( LWNODEINPUT_GLOBAL,  GFUSE_TRANSIENT );
NodeOutputFuncs *outFuncs = global( LWNODEOUTPUT_GLOBAL, GFUSE_TRANSIENT );
LWNodeFuncs     *nodeFuncs = global( LWNODEFUNCS_GLOBAL, GFUSE_TRANSIENT );
```

---

## ConnectionType Constants

```c
typedef enum {
    NOT_RGB       = 1,   /* 3 doubles (r, g, b) */
    NOT_SCALAR,          /* 1 double            */
    NOT_VECTOR,          /* 3 doubles (x, y, z) */
    NOT_INTEGER,         /* 1 int               */
    NOT_FUNCTION,        /* scalar bidirectional */
    NOT_PROJECTION,      /* LWNodalProjection*  */
    NOT_MATRIX44,        /* 4x4 matrix          */
    NOT_BSDF,
    NOT_FRESNEL,
    NOT_VOLUME,
    NOT_CUSTOM           /* plugin-defined       */
} ConnectionType;
```

---

## Creating Inputs and Outputs

Call in your `Create()` callback:

```c
/* NodeInputFuncs->create( nodeID, type, name, eventCallback ) */
NodeInputID in_color  = inFuncs->create( nodeID, NOT_RGB,    "Color",  NULL );
NodeInputID in_scale  = inFuncs->create( nodeID, NOT_SCALAR, "Scale",  NULL );
NodeInputID in_vec    = inFuncs->create( nodeID, NOT_VECTOR, "Vector", NULL );

/* NodeOutputFuncs->create( nodeID, type, name ) */
NodeOutputID out_rgb  = outFuncs->create( nodeID, NOT_RGB,    "Result" );
NodeOutputID out_val  = outFuncs->create( nodeID, NOT_SCALAR, "Value"  );
```

---

## Evaluate Pattern

```c
static void
Evaluate( LWInstance inst, LWShadingGeometry *sg,
          NodeOutputID outputID, NodeValue value )
{
    /* 1. Declare value buffers matching input types */
    double color[3]  = { 1.0, 1.0, 1.0 };   /* default if not connected */
    double scale     = 1.0;

    /* 2. Read connected inputs — overwrites defaults if wired */
    inFuncs->evaluate( dat->in_color, sg, color  );
    inFuncs->evaluate( dat->in_scale, sg, &scale );

    /* 3. Compute */
    double result[3] = {
        color[0] * scale,
        color[1] * scale,
        color[2] * scale
    };

    /* 4. Set ONLY the requested output */
    if ( outputID == dat->out_rgb )
        outFuncs->setValue( value, result );

    /* You can have multiple outputs — only set the one matching outputID */
}
```

---

## LWShadingGeometry — Key Fields

Available via `sg->` inside `Evaluate`:

```c
sg->oPos[3]    /* object-space position   */
sg->wPos[3]    /* world-space position    */
sg->gNorm[3]   /* geometric normal        */
sg->wNorm[3]   /* shading normal          */
sg->uv[2]      /* UV coordinates          */
sg->dpdu[3]    /* UV tangents             */
sg->dpdv[3]
```

Full definition in `lwprimitive.h`.

---

## Input Connection Check

```c
/* Check if an input is connected to another node's output */
if ( inFuncs->check( dat->in_color ) )
    inFuncs->evaluate( dat->in_color, sg, color );
else
    /* use fallback default */
    memcpy( color, dat->defaultColor, sizeof(color) );
```

---

## Node Display Color

Set a visual color for the node header in the editor:

```c
LWNodeFuncs *nf = global( LWNODEFUNCS_GLOBAL, GFUSE_TRANSIENT );
if ( nf ) nf->setNodeColor3( nodeID, 80, 140, 200 );   /* R G B, 0-255 */
```

---

## ServerDesc — Node + Interface

```c
ServerRecord ServerDesc[] = {
    { LWNODEHANDLER_CLASS, "MyNode",           Activate  },
    { LWNODEHANDLER_CLASS, "MyNode_Interface", Interface },
    { NULL }
};
```

---

## macOS Build

```bash
SDK="/Users/mac/Applications/Lightwave3d_2024.2.0/sdk/include"
clang -dynamiclib -I"$SDK" -o MyNode.p MyNode.c \
      -lm -framework CoreFoundation -arch arm64 -arch x86_64
xattr -d com.apple.quarantine MyNode.p
```

---

## Gotchas

1. **`Evaluate` is called per shading point** — keep it fast; avoid allocations.
2. **Only set the output matching `outputID`** — setting all outputs every call
   wastes time; downstream nodes only request what they need.
3. **Always provide defaults** before calling `inFuncs->evaluate()` — if the input
   is not connected, the buffer is left unchanged, so the default acts as fallback.
4. **Input/output IDs are only valid after `Create()` returns** — store them in
   your instance data.
5. **Cache global function pointers in instance data** — calling `global()` inside
   `Evaluate` is slow; obtain them once in `Create()`.
6. **`globalFunc` must be stored** before `Create()` is called — save it at
   activation time into a static or passed via `priv`.
7. **Load/Save must match order** — node parameters read out of order produce silent corruption.
