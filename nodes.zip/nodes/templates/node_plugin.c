/*
 * PLUGIN_NAME — LightWave NodeHandler Plugin (C/C++)
 * TODO: Replace PLUGIN_NAME throughout this file
 *
 * TEMPLATE: NodeHandler
 * Nodes appear in the LightWave Node Editor on surfaces, environments,
 * and other nodal contexts. Each node has typed inputs and outputs.
 * The evaluate() function reads connected inputs and sets output values
 * each time the node is evaluated during rendering.
 */

#include <lwserver.h>
#include <lwnodes.h>        /* NodeHandler, ConnectionType, NodeValue */
#include <lwxpanel.h>
#include <lwmessage.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* ------------------------------------------------------------------ */
/* Instance data                                                         */
/* ------------------------------------------------------------------ */
typedef struct {
    NodeID       nodeID;      /* this node's ID in the editor */

    /* Input IDs — created in Create(), used in Evaluate() */
    NodeInputID  in_color;    /* TODO: rename/add your inputs  */
    NodeInputID  in_scale;

    /* Output IDs */
    NodeOutputID out_color;   /* TODO: rename/add your outputs */
    NodeOutputID out_scalar;

    /* Parameters (editable via UI) */
    double       scale;
    double       color[3];

    /* Cached globals */
    NodeInputFuncs  *inFuncs;
    NodeOutputFuncs *outFuncs;
} MyNode;

/* Global globals pointer — set during activation */
static GlobalFunc *G = NULL;

/* ------------------------------------------------------------------ */
/* Instance callbacks                                                   */
/* ------------------------------------------------------------------ */

static LWInstance
Create( void *priv, NodeID nodeID, LWError *err )
{
    MyNode *dat = (MyNode *)calloc( 1, sizeof(MyNode) );
    if ( !dat ) { *err = "Out of memory"; return NULL; }

    dat->nodeID = nodeID;

    /* Get node I/O function tables */
    LWNodeFuncs *nodeFuncs = G( LWNODEINPUT_GLOBAL,  GFUSE_TRANSIENT );
    dat->inFuncs  = G( LWNODEINPUT_GLOBAL,  GFUSE_TRANSIENT );
    dat->outFuncs = G( LWNODEOUTPUT_GLOBAL, GFUSE_TRANSIENT );

    /* Defaults */
    dat->scale    = 1.0;
    dat->color[0] = 1.0; dat->color[1] = 1.0; dat->color[2] = 1.0;

    /* Create inputs */
    dat->in_color = dat->inFuncs->create( nodeID, NOT_RGB,    "Color", NULL );
    dat->in_scale = dat->inFuncs->create( nodeID, NOT_SCALAR, "Scale", NULL );

    /* Create outputs */
    dat->out_color  = dat->outFuncs->create( nodeID, NOT_RGB,    "Color"  );
    dat->out_scalar = dat->outFuncs->create( nodeID, NOT_SCALAR, "Scalar" );

    /* TODO: set node display color (RGB 0-255) */
    /* LWNodeFuncs *nf = G( LWNODEFUNCS_GLOBAL, GFUSE_TRANSIENT );
       if (nf) nf->setNodeColor3( nodeID, 80, 140, 200 ); */

    return (LWInstance)dat;
}

static void
Destroy( LWInstance inst )
{
    if ( inst ) free( inst );
}

static LWError
Copy( LWInstance to, LWInstance from )
{
    MyNode *src = (MyNode *)from;
    MyNode *dst = (MyNode *)to;
    dst->scale    = src->scale;
    dst->color[0] = src->color[0];
    dst->color[1] = src->color[1];
    dst->color[2] = src->color[2];
    return NULL;
}

static LWError
Load( LWInstance inst, const LWLoadState *ls )
{
    MyNode *dat = (MyNode *)inst;
    LWLOAD_FP ( ls, &dat->scale,    1 );
    LWLOAD_FP ( ls, dat->color,     3 );
    return NULL;
}

static LWError
Save( LWInstance inst, const LWSaveState *ss )
{
    MyNode *dat = (MyNode *)inst;
    LWSAVE_FP ( ss, &dat->scale,    1 );
    LWSAVE_FP ( ss, dat->color,     3 );
    return NULL;
}

static const char *
Descln( LWInstance inst )
{
    static char buf[64];
    MyNode *dat = (MyNode *)inst;
    sprintf( buf, "Scale=%.2f", dat->scale );
    return buf;
}

/* ------------------------------------------------------------------ */
/* Evaluate — called per shading point during render                    */
/* ------------------------------------------------------------------ */

static void
Evaluate( LWInstance inst, LWShadingGeometry *sg,
          NodeOutputID outputID, NodeValue value )
{
    MyNode *dat = (MyNode *)inst;

    /* ---- Read inputs ---- */
    double inColor[3] = { dat->color[0], dat->color[1], dat->color[2] };
    double inScale    = dat->scale;

    /* Evaluate connected inputs (overrides defaults if wired) */
    dat->inFuncs->evaluate( dat->in_color, sg, inColor  );
    dat->inFuncs->evaluate( dat->in_scale, sg, &inScale );

    /* ---- Compute ---- */
    /* TODO: your node math here, e.g.: */
    double outColor[3];
    outColor[0] = inColor[0] * inScale;
    outColor[1] = inColor[1] * inScale;
    outColor[2] = inColor[2] * inScale;
    double outScalar = ( outColor[0] + outColor[1] + outColor[2] ) / 3.0;

    /* ---- Set outputs ---- */
    /* Only set the output that is being requested */
    if ( outputID == dat->out_color )
        dat->outFuncs->setValue( value, outColor );

    else if ( outputID == dat->out_scalar )
        dat->outFuncs->setValue( value, &outScalar );
}

/* ------------------------------------------------------------------ */
/* Flags                                                                 */
/* ------------------------------------------------------------------ */

static unsigned int
Flags( LWInstance inst )
{
    return 0;   /* TODO: set node flags if needed */
}

/* ------------------------------------------------------------------ */
/* Interface activation (XPanels)                                       */
/* ------------------------------------------------------------------ */

#define CTRL_SCALE  1
#define CTRL_COLOR  2

static LWXPanelHint panelHints[] = {
    XpLABEL ( 0,          "PLUGIN_NAME" ),
    XpF64   ( CTRL_SCALE, "Scale" ),
    /* TODO: add color control, more parameters */
    XpEND
};

XCALL_( static int )
Interface( int version, GlobalFunc *global,
           LWInterface *local, void *serverData )
{
    LWXPanelFuncs *xpanf = global( LWXPANELFUNCS_GLOBAL, GFUSE_TRANSIENT );
    MyNode        *dat   = (MyNode *)local->inst;
    if ( !xpanf ) return AFUNC_BADGLOBAL;

    local->panel   = xpanf->create( LWXP_VIEW, panelHints );
    local->options = NULL;
    local->command = NULL;

    if ( local->panel )
        xpanf->formSet( local->panel, CTRL_SCALE, &dat->scale );

    return AFUNC_OK;
}

/* ------------------------------------------------------------------ */
/* Activation function                                                   */
/* ------------------------------------------------------------------ */

XCALL_( int )
Activate( int version, GlobalFunc *global,
          LWNodeHandler *local, void *serverData )
{
    if ( version != LWNODEHANDLER_VERSION )
        return AFUNC_BADVERSION;

    G = global;   /* cache for use in Create */

    local->inst->create  = Create;
    local->inst->destroy = Destroy;
    local->inst->copy    = Copy;
    local->inst->load    = Load;
    local->inst->save    = Save;
    local->inst->descln  = Descln;

    if ( local->item ) {
        local->item->useItems = NULL;   /* TODO: set if node reads scene items */
        local->item->changeID = NULL;
    }

    local->evaluate      = Evaluate;
    local->flags         = Flags;
    local->customPreview = NULL;   /* optional thumbnail override */
    local->materialGL    = NULL;   /* optional OpenGL preview     */

    return AFUNC_OK;
}

/* ------------------------------------------------------------------ */
/* Server record                                                         */
/* ------------------------------------------------------------------ */
ServerRecord ServerDesc[] = {
    { LWNODEHANDLER_CLASS, "PLUGIN_NAME",           Activate  },
    { LWNODEHANDLER_CLASS, "PLUGIN_NAME_Interface", Interface },
    { NULL }
};
